namespace Setup
{
    partial class frmSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSetup));
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.gpbSQLConn = new System.Windows.Forms.GroupBox();
            this.txtDBName = new System.Windows.Forms.TextBox();
            this.lbl_DBName = new System.Windows.Forms.Label();
            this.txtServerName = new System.Windows.Forms.TextBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.lbl_DBUserID = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.MaskedTextBox();
            this.lbl_DBPwd = new System.Windows.Forms.Label();
            this.lbl_Server = new System.Windows.Forms.Label();
            this.lblAPIKey = new System.Windows.Forms.Label();
            this.txtAPIKey = new System.Windows.Forms.TextBox();
            this.gpbAccpac = new System.Windows.Forms.GroupBox();
            this.txt_AccpacCompanyID = new System.Windows.Forms.TextBox();
            this.lbl_AccpacCompanyID = new System.Windows.Forms.Label();
            this.txt_AccpacPwd = new System.Windows.Forms.TextBox();
            this.lbl_AccpacPassword = new System.Windows.Forms.Label();
            this.txt_AccpacUserID = new System.Windows.Forms.TextBox();
            this.lbl_AccpacUserID = new System.Windows.Forms.Label();
            this.lbl_TimesOfRetry = new System.Windows.Forms.Label();
            this.cmb_Retry = new System.Windows.Forms.ComboBox();
            this.txt_RetrialInterval = new System.Windows.Forms.TextBox();
            this.lbl_RetrialInterval = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Process = new System.Windows.Forms.Label();
            this.lbl_POUrl = new System.Windows.Forms.Label();
            this.lbl_OEUrl = new System.Windows.Forms.Label();
            this.lbl_ICUrl = new System.Windows.Forms.Label();
            this.lbl_WebUser = new System.Windows.Forms.Label();
            this.txt_POUrl = new System.Windows.Forms.TextBox();
            this.txt_OEUrl = new System.Windows.Forms.TextBox();
            this.txt_ICUrl = new System.Windows.Forms.TextBox();
            this.txt_WebUser = new System.Windows.Forms.TextBox();
            this.gpbSQLConn.SuspendLayout();
            this.gpbAccpac.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(20, 815);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(112, 35);
            this.btnSave.TabIndex = 16;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(645, 815);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(112, 35);
            this.btnClose.TabIndex = 17;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // gpbSQLConn
            // 
            this.gpbSQLConn.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gpbSQLConn.Controls.Add(this.txtDBName);
            this.gpbSQLConn.Controls.Add(this.lbl_DBName);
            this.gpbSQLConn.Controls.Add(this.txtServerName);
            this.gpbSQLConn.Controls.Add(this.txtUser);
            this.gpbSQLConn.Controls.Add(this.lbl_DBUserID);
            this.gpbSQLConn.Controls.Add(this.txtPassword);
            this.gpbSQLConn.Controls.Add(this.lbl_DBPwd);
            this.gpbSQLConn.Controls.Add(this.lbl_Server);
            this.gpbSQLConn.Location = new System.Drawing.Point(14, 14);
            this.gpbSQLConn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbSQLConn.Name = "gpbSQLConn";
            this.gpbSQLConn.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbSQLConn.Size = new System.Drawing.Size(461, 209);
            this.gpbSQLConn.TabIndex = 0;
            this.gpbSQLConn.TabStop = false;
            this.gpbSQLConn.Text = "SQL Connection";
            // 
            // txtDBName
            // 
            this.txtDBName.Location = new System.Drawing.Point(170, 77);
            this.txtDBName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDBName.MaxLength = 30;
            this.txtDBName.Name = "txtDBName";
            this.txtDBName.Size = new System.Drawing.Size(268, 26);
            this.txtDBName.TabIndex = 2;
            // 
            // lbl_DBName
            // 
            this.lbl_DBName.AutoSize = true;
            this.lbl_DBName.Location = new System.Drawing.Point(8, 80);
            this.lbl_DBName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_DBName.Name = "lbl_DBName";
            this.lbl_DBName.Size = new System.Drawing.Size(125, 20);
            this.lbl_DBName.TabIndex = 12;
            this.lbl_DBName.Text = "Database Name";
            // 
            // txtServerName
            // 
            this.txtServerName.Location = new System.Drawing.Point(170, 37);
            this.txtServerName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtServerName.MaxLength = 30;
            this.txtServerName.Name = "txtServerName";
            this.txtServerName.Size = new System.Drawing.Size(268, 26);
            this.txtServerName.TabIndex = 1;
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(170, 117);
            this.txtUser.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtUser.MaxLength = 30;
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(268, 26);
            this.txtUser.TabIndex = 3;
            // 
            // lbl_DBUserID
            // 
            this.lbl_DBUserID.AutoSize = true;
            this.lbl_DBUserID.Location = new System.Drawing.Point(8, 120);
            this.lbl_DBUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_DBUserID.Name = "lbl_DBUserID";
            this.lbl_DBUserID.Size = new System.Drawing.Size(138, 20);
            this.lbl_DBUserID.TabIndex = 10;
            this.lbl_DBUserID.Text = "Database User ID";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(170, 155);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(268, 26);
            this.txtPassword.TabIndex = 4;
            // 
            // lbl_DBPwd
            // 
            this.lbl_DBPwd.AutoSize = true;
            this.lbl_DBPwd.Location = new System.Drawing.Point(8, 158);
            this.lbl_DBPwd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_DBPwd.Name = "lbl_DBPwd";
            this.lbl_DBPwd.Size = new System.Drawing.Size(152, 20);
            this.lbl_DBPwd.TabIndex = 11;
            this.lbl_DBPwd.Text = "Database Password";
            // 
            // lbl_Server
            // 
            this.lbl_Server.AutoSize = true;
            this.lbl_Server.Location = new System.Drawing.Point(8, 40);
            this.lbl_Server.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Server.Name = "lbl_Server";
            this.lbl_Server.Size = new System.Drawing.Size(101, 20);
            this.lbl_Server.TabIndex = 9;
            this.lbl_Server.Text = "Server Name";
            // 
            // lblAPIKey
            // 
            this.lblAPIKey.AutoSize = true;
            this.lblAPIKey.Location = new System.Drawing.Point(22, 409);
            this.lblAPIKey.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAPIKey.Name = "lblAPIKey";
            this.lblAPIKey.Size = new System.Drawing.Size(65, 20);
            this.lblAPIKey.TabIndex = 13;
            this.lblAPIKey.Text = "API Key";
            // 
            // txtAPIKey
            // 
            this.txtAPIKey.Location = new System.Drawing.Point(184, 405);
            this.txtAPIKey.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAPIKey.Name = "txtAPIKey";
            this.txtAPIKey.Size = new System.Drawing.Size(268, 26);
            this.txtAPIKey.TabIndex = 9;
            // 
            // gpbAccpac
            // 
            this.gpbAccpac.Controls.Add(this.txt_AccpacCompanyID);
            this.gpbAccpac.Controls.Add(this.lbl_AccpacCompanyID);
            this.gpbAccpac.Controls.Add(this.txt_AccpacPwd);
            this.gpbAccpac.Controls.Add(this.lbl_AccpacPassword);
            this.gpbAccpac.Controls.Add(this.txt_AccpacUserID);
            this.gpbAccpac.Controls.Add(this.lbl_AccpacUserID);
            this.gpbAccpac.Location = new System.Drawing.Point(14, 232);
            this.gpbAccpac.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbAccpac.Name = "gpbAccpac";
            this.gpbAccpac.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbAccpac.Size = new System.Drawing.Size(461, 163);
            this.gpbAccpac.TabIndex = 5;
            this.gpbAccpac.TabStop = false;
            this.gpbAccpac.Text = "Accpac Connection";
            // 
            // txt_AccpacCompanyID
            // 
            this.txt_AccpacCompanyID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_AccpacCompanyID.Location = new System.Drawing.Point(170, 29);
            this.txt_AccpacCompanyID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_AccpacCompanyID.Name = "txt_AccpacCompanyID";
            this.txt_AccpacCompanyID.Size = new System.Drawing.Size(268, 26);
            this.txt_AccpacCompanyID.TabIndex = 6;
            // 
            // lbl_AccpacCompanyID
            // 
            this.lbl_AccpacCompanyID.AutoSize = true;
            this.lbl_AccpacCompanyID.Location = new System.Drawing.Point(9, 34);
            this.lbl_AccpacCompanyID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_AccpacCompanyID.Name = "lbl_AccpacCompanyID";
            this.lbl_AccpacCompanyID.Size = new System.Drawing.Size(97, 20);
            this.lbl_AccpacCompanyID.TabIndex = 15;
            this.lbl_AccpacCompanyID.Text = "Company ID";
            // 
            // txt_AccpacPwd
            // 
            this.txt_AccpacPwd.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_AccpacPwd.Location = new System.Drawing.Point(170, 108);
            this.txt_AccpacPwd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_AccpacPwd.Name = "txt_AccpacPwd";
            this.txt_AccpacPwd.PasswordChar = '*';
            this.txt_AccpacPwd.Size = new System.Drawing.Size(268, 26);
            this.txt_AccpacPwd.TabIndex = 8;
            // 
            // lbl_AccpacPassword
            // 
            this.lbl_AccpacPassword.AutoSize = true;
            this.lbl_AccpacPassword.Location = new System.Drawing.Point(8, 112);
            this.lbl_AccpacPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_AccpacPassword.Name = "lbl_AccpacPassword";
            this.lbl_AccpacPassword.Size = new System.Drawing.Size(78, 20);
            this.lbl_AccpacPassword.TabIndex = 14;
            this.lbl_AccpacPassword.Text = "Password";
            // 
            // txt_AccpacUserID
            // 
            this.txt_AccpacUserID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txt_AccpacUserID.Location = new System.Drawing.Point(170, 68);
            this.txt_AccpacUserID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_AccpacUserID.Name = "txt_AccpacUserID";
            this.txt_AccpacUserID.Size = new System.Drawing.Size(268, 26);
            this.txt_AccpacUserID.TabIndex = 7;
            // 
            // lbl_AccpacUserID
            // 
            this.lbl_AccpacUserID.AutoSize = true;
            this.lbl_AccpacUserID.Location = new System.Drawing.Point(8, 75);
            this.lbl_AccpacUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_AccpacUserID.Name = "lbl_AccpacUserID";
            this.lbl_AccpacUserID.Size = new System.Drawing.Size(64, 20);
            this.lbl_AccpacUserID.TabIndex = 13;
            this.lbl_AccpacUserID.Text = "User ID";
            // 
            // lbl_TimesOfRetry
            // 
            this.lbl_TimesOfRetry.AutoSize = true;
            this.lbl_TimesOfRetry.Location = new System.Drawing.Point(22, 449);
            this.lbl_TimesOfRetry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_TimesOfRetry.Name = "lbl_TimesOfRetry";
            this.lbl_TimesOfRetry.Size = new System.Drawing.Size(133, 20);
            this.lbl_TimesOfRetry.TabIndex = 15;
            this.lbl_TimesOfRetry.Text = "Numbers of Retry";
            // 
            // cmb_Retry
            // 
            this.cmb_Retry.FormattingEnabled = true;
            this.cmb_Retry.Location = new System.Drawing.Point(184, 446);
            this.cmb_Retry.Name = "cmb_Retry";
            this.cmb_Retry.Size = new System.Drawing.Size(270, 28);
            this.cmb_Retry.TabIndex = 10;
            this.cmb_Retry.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cmb_Retry_KeyPress);
            // 
            // txt_RetrialInterval
            // 
            this.txt_RetrialInterval.Location = new System.Drawing.Point(184, 492);
            this.txt_RetrialInterval.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_RetrialInterval.MaxLength = 2;
            this.txt_RetrialInterval.Name = "txt_RetrialInterval";
            this.txt_RetrialInterval.Size = new System.Drawing.Size(188, 26);
            this.txt_RetrialInterval.TabIndex = 11;
            this.txt_RetrialInterval.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_RetrialInterval.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_RetrialInterval_KeyPress);
            // 
            // lbl_RetrialInterval
            // 
            this.lbl_RetrialInterval.AutoSize = true;
            this.lbl_RetrialInterval.Location = new System.Drawing.Point(22, 496);
            this.lbl_RetrialInterval.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_RetrialInterval.Name = "lbl_RetrialInterval";
            this.lbl_RetrialInterval.Size = new System.Drawing.Size(111, 20);
            this.lbl_RetrialInterval.TabIndex = 17;
            this.lbl_RetrialInterval.Text = "Retrial Interval";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(379, 495);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 20);
            this.label1.TabIndex = 18;
            this.label1.Text = "Minute(s)";
            // 
            // lbl_Process
            // 
            this.lbl_Process.AutoSize = true;
            this.lbl_Process.Location = new System.Drawing.Point(23, 779);
            this.lbl_Process.Name = "lbl_Process";
            this.lbl_Process.Size = new System.Drawing.Size(55, 20);
            this.lbl_Process.TabIndex = 19;
            this.lbl_Process.Text = "Ready";
            this.lbl_Process.Visible = false;
            // 
            // lbl_POUrl
            // 
            this.lbl_POUrl.AutoSize = true;
            this.lbl_POUrl.Location = new System.Drawing.Point(22, 542);
            this.lbl_POUrl.Name = "lbl_POUrl";
            this.lbl_POUrl.Size = new System.Drawing.Size(122, 20);
            this.lbl_POUrl.TabIndex = 20;
            this.lbl_POUrl.Text = "PO Web API Url";
            // 
            // lbl_OEUrl
            // 
            this.lbl_OEUrl.AutoSize = true;
            this.lbl_OEUrl.Location = new System.Drawing.Point(22, 584);
            this.lbl_OEUrl.Name = "lbl_OEUrl";
            this.lbl_OEUrl.Size = new System.Drawing.Size(123, 20);
            this.lbl_OEUrl.TabIndex = 21;
            this.lbl_OEUrl.Text = "OE Web API Url";
            // 
            // lbl_ICUrl
            // 
            this.lbl_ICUrl.AutoSize = true;
            this.lbl_ICUrl.Location = new System.Drawing.Point(22, 622);
            this.lbl_ICUrl.Name = "lbl_ICUrl";
            this.lbl_ICUrl.Size = new System.Drawing.Size(116, 20);
            this.lbl_ICUrl.TabIndex = 22;
            this.lbl_ICUrl.Text = "IC Web API Url";
            // 
            // lbl_WebUser
            // 
            this.lbl_WebUser.AutoSize = true;
            this.lbl_WebUser.Location = new System.Drawing.Point(22, 664);
            this.lbl_WebUser.Name = "lbl_WebUser";
            this.lbl_WebUser.Size = new System.Drawing.Size(110, 20);
            this.lbl_WebUser.TabIndex = 23;
            this.lbl_WebUser.Text = "Web API User";
            // 
            // txt_POUrl
            // 
            this.txt_POUrl.Location = new System.Drawing.Point(184, 536);
            this.txt_POUrl.Name = "txt_POUrl";
            this.txt_POUrl.Size = new System.Drawing.Size(573, 26);
            this.txt_POUrl.TabIndex = 12;
            // 
            // txt_OEUrl
            // 
            this.txt_OEUrl.Location = new System.Drawing.Point(184, 578);
            this.txt_OEUrl.Name = "txt_OEUrl";
            this.txt_OEUrl.Size = new System.Drawing.Size(573, 26);
            this.txt_OEUrl.TabIndex = 13;
            // 
            // txt_ICUrl
            // 
            this.txt_ICUrl.Location = new System.Drawing.Point(184, 616);
            this.txt_ICUrl.Name = "txt_ICUrl";
            this.txt_ICUrl.Size = new System.Drawing.Size(573, 26);
            this.txt_ICUrl.TabIndex = 14;
            // 
            // txt_WebUser
            // 
            this.txt_WebUser.Location = new System.Drawing.Point(184, 658);
            this.txt_WebUser.Name = "txt_WebUser";
            this.txt_WebUser.Size = new System.Drawing.Size(142, 26);
            this.txt_WebUser.TabIndex = 15;
            // 
            // frmSetup
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(778, 864);
            this.Controls.Add(this.txt_WebUser);
            this.Controls.Add(this.txt_ICUrl);
            this.Controls.Add(this.txt_OEUrl);
            this.Controls.Add(this.txt_POUrl);
            this.Controls.Add(this.lbl_WebUser);
            this.Controls.Add(this.lbl_ICUrl);
            this.Controls.Add(this.lbl_OEUrl);
            this.Controls.Add(this.lbl_POUrl);
            this.Controls.Add(this.lbl_Process);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_RetrialInterval);
            this.Controls.Add(this.lbl_RetrialInterval);
            this.Controls.Add(this.cmb_Retry);
            this.Controls.Add(this.lbl_TimesOfRetry);
            this.Controls.Add(this.gpbAccpac);
            this.Controls.Add(this.txtAPIKey);
            this.Controls.Add(this.lblAPIKey);
            this.Controls.Add(this.gpbSQLConn);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(494, 354);
            this.Name = "frmSetup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Setting Program";
            this.Load += new System.EventHandler(this.frmSetup_Load);
            this.gpbSQLConn.ResumeLayout(false);
            this.gpbSQLConn.PerformLayout();
            this.gpbAccpac.ResumeLayout(false);
            this.gpbAccpac.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox gpbSQLConn;
        private System.Windows.Forms.TextBox txtServerName;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label lbl_DBUserID;
        private System.Windows.Forms.MaskedTextBox txtPassword;
        private System.Windows.Forms.Label lbl_DBPwd;
        private System.Windows.Forms.Label lbl_Server;
        private System.Windows.Forms.TextBox txtDBName;
        private System.Windows.Forms.Label lbl_DBName;
        private System.Windows.Forms.Label lblAPIKey;
        private System.Windows.Forms.TextBox txtAPIKey;
        private System.Windows.Forms.GroupBox gpbAccpac;
        private System.Windows.Forms.TextBox txt_AccpacCompanyID;
        private System.Windows.Forms.Label lbl_AccpacCompanyID;
        private System.Windows.Forms.TextBox txt_AccpacPwd;
        private System.Windows.Forms.Label lbl_AccpacPassword;
        private System.Windows.Forms.TextBox txt_AccpacUserID;
        private System.Windows.Forms.Label lbl_AccpacUserID;
        private System.Windows.Forms.Label lbl_TimesOfRetry;
        private System.Windows.Forms.ComboBox cmb_Retry;
        private System.Windows.Forms.TextBox txt_RetrialInterval;
        private System.Windows.Forms.Label lbl_RetrialInterval;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Process;
        private System.Windows.Forms.Label lbl_POUrl;
        private System.Windows.Forms.Label lbl_OEUrl;
        private System.Windows.Forms.Label lbl_ICUrl;
        private System.Windows.Forms.Label lbl_WebUser;
        private System.Windows.Forms.TextBox txt_POUrl;
        private System.Windows.Forms.TextBox txt_OEUrl;
        private System.Windows.Forms.TextBox txt_ICUrl;
        private System.Windows.Forms.TextBox txt_WebUser;
    }
}

