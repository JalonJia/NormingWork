using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CommonTools;
using System.IO;
using AccpacBL;

namespace Setup
{
    public partial class frmSetup : Form
    {
        INIHelper _iniHelper;
        string _strIniFile = string.Empty;
        string _strKey = string.Empty;

        public frmSetup()
        {
            InitializeComponent();
        }

        private void frmSetup_Load(object sender, EventArgs e)
        {
            string sValue = string.Empty;

            cmb_Retry.Items.Add("1");
            cmb_Retry.Items.Add("3");
            cmb_Retry.Items.Add("5");

            _strIniFile = Application.StartupPath + @"\" + publicVar.STR_SETTING_FILE_NAME;
            if (!File.Exists(_strIniFile))
            {
               FileStream iniFile = File.Create(_strIniFile);
               iniFile.Close();
            }

            _iniHelper = new INIHelper(_strIniFile);
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_SERVER_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txtServerName.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_DATABASE_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txtDBName.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_USER_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txtUser.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_PASSWORD_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txtPassword.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_ACCPAC_COMPANY_ID_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txt_AccpacCompanyID.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_ACCPAC_USER_ID_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txt_AccpacUserID.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_ACCPAC_PASSWORD_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txt_AccpacPwd.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_APIKEY_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txtAPIKey.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_RETRY_COUNT_CAPTION);
            if (string.IsNullOrEmpty(sValue))
            {
                cmb_Retry.Text = "1";
            }
            else
            {
                cmb_Retry.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_RETRIAL_INTERVAL_CAPTION);
            if (string.IsNullOrEmpty(sValue))
            {
                txt_RetrialInterval.Text = "1";
            }
            else
            {
                txt_RetrialInterval.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_URL_PO_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txt_POUrl.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_URL_OE_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txt_OEUrl.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_URL_IC_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txt_ICUrl.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }
            sValue = _iniHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_USER_CAPTION);
            if (string.IsNullOrEmpty(sValue) == false)
            {
                txt_WebUser.Text = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
            }

            txtServerName.Focus();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private bool ValidateOpenSQL(string strServer, string strDatabase, string strUser, string strPassword)
        {
            string connectionString = "Server=" + strServer + ";database=" + strDatabase + ";uid=" + strUser + ";pwd=" + strPassword;
            DbTools.ConnectionString = connectionString;
            return DbTools.CheckConnection();
        }

        private bool CreateLogTables(string strServer, string strDatabase, string strUser, string strPassword, out string sError)
        {
            string sSQL = string.Empty;
            string connectionString = string.Empty;
            sError = string.Empty;

            try
            {
                connectionString = "Server=" + strServer + ";database=" + strDatabase + ";uid=" + strUser + ";pwd=" + strPassword;
                DbTools.ConnectionString = connectionString;

                sSQL = "USE [" + txtDBName.Text.Trim() + "]" + Environment.NewLine;
                sSQL = sSQL + "SET ANSI_NULLS ON" + Environment.NewLine + "SET QUOTED_IDENTIFIER ON" + Environment.NewLine + "SET ANSI_PADDING ON" + Environment.NewLine;
                sSQL = sSQL + "IF OBJECT_ID('dbo." + publicVar.STR_LOGTABLE_POORDER + "') IS NULL" + Environment.NewLine;
                sSQL = sSQL + "CREATE TABLE [dbo].[" + publicVar.STR_LOGTABLE_POORDER + "](" + Environment.NewLine;
                sSQL = sSQL + "    [PORHSEQ] [decimal](19,0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [AUDTDATE] [decimal](9,0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [AUDTTIME] [decimal](9,0) DEFAULT(0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [PONUMBER] [char](22) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [EMPLOYERCODE] [char](60) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [VDCODE] [char](12) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [ARRIVALDATE] [char](10) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [CREATEDATE] [datetime] DEFAULT GETDATE() NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [SYNSTATUS] [smallint] DEFAULT(0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "CONSTRAINT [PK_" + publicVar.STR_LOGTABLE_POORDER + "] PRIMARY KEY CLUSTERED" + Environment.NewLine + "(" + Environment.NewLine;
                sSQL = sSQL + "    [PORHSEQ] ASC" + Environment.NewLine;
                sSQL = sSQL + ") ON [PRIMARY]" + Environment.NewLine + ") ON [PRIMARY]" + Environment.NewLine + "SET ANSI_PADDING OFF";

                DbTools.ExecuteSql(sSQL.Trim());

                sSQL = "USE [" + txtDBName.Text.Trim() + "]" + Environment.NewLine;
                sSQL = sSQL + "SET ANSI_NULLS ON" + Environment.NewLine + "SET QUOTED_IDENTIFIER ON" + Environment.NewLine + "SET ANSI_PADDING ON" + Environment.NewLine;
                sSQL = sSQL + "IF OBJECT_ID('dbo." + publicVar.STR_LOGTABLE_OESHIP + "') IS NULL" + Environment.NewLine;
                sSQL = sSQL + "CREATE TABLE [dbo].[" + publicVar.STR_LOGTABLE_OESHIP + "](" + Environment.NewLine;
                sSQL = sSQL + "    [SHIUNIQ] [decimal](19,0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [AUDTDATE] [decimal](9,0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [AUDTTIME] [decimal](9,0) DEFAULT(0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [SHINUMBER] [char](22) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [EMPLOYERCODE] [char](60) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [STOREID] [char](60) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [IDCUST] [char](12) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [ARRIVALDATE] [char](10) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [CREATEDATE] [datetime] DEFAULT GETDATE() NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [SYNSTATUS] [smallint] DEFAULT(0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "CONSTRAINT [PK_" + publicVar.STR_LOGTABLE_OESHIP + "] PRIMARY KEY CLUSTERED" + Environment.NewLine + "(" + Environment.NewLine;
                sSQL = sSQL + "    [SHIUNIQ] ASC" + Environment.NewLine;
                sSQL = sSQL + ") ON [PRIMARY]" + Environment.NewLine + ") ON [PRIMARY]" + Environment.NewLine + "SET ANSI_PADDING OFF";

                DbTools.ExecuteSql(sSQL.Trim());

                sSQL = "USE [" + txtDBName.Text.Trim() + "]" + Environment.NewLine;
                sSQL = sSQL + "SET ANSI_NULLS ON" + Environment.NewLine + "SET QUOTED_IDENTIFIER ON" + Environment.NewLine + "SET ANSI_PADDING ON" + Environment.NewLine;
                sSQL = sSQL + "IF OBJECT_ID('dbo." + publicVar.STR_LOGTABLE_ICINT + "') IS NULL" + Environment.NewLine;
                sSQL = sSQL + "CREATE TABLE [dbo].[" + publicVar.STR_LOGTABLE_ICINT + "](" + Environment.NewLine;
                sSQL = sSQL + "    [SEQUENCENO] [int] NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [AUDTDATE] [decimal](9,0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [AUDTTIME] [decimal](9,0) DEFAULT(0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [DOCNUM] [char](22) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [EMPLOYERCODE] [char](60) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [STOREID] [char](60) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [ARRIVALDATE] [char](10) DEFAULT('') NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [CREATEDATE] [datetime] DEFAULT GETDATE() NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "    [SYNSTATUS] [smallint] DEFAULT(0) NOT NULL," + Environment.NewLine;
                sSQL = sSQL + "CONSTRAINT [PK_" + publicVar.STR_LOGTABLE_ICINT + "] PRIMARY KEY CLUSTERED" + Environment.NewLine + "(" + Environment.NewLine;
                sSQL = sSQL + "    [SEQUENCENO] ASC" + Environment.NewLine;
                sSQL = sSQL + ") ON [PRIMARY]" + Environment.NewLine + ") ON [PRIMARY]" + Environment.NewLine + "SET ANSI_PADDING OFF";

                DbTools.ExecuteSql(sSQL.Trim());
                return true;
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();

                return false;
            }
        }

        private void ControlEnabled(bool bEnabled)
        {
            if (bEnabled)
            {
                lbl_Process.Text = "Ready";
                Application.DoEvents();
            }
            else
            {

                lbl_Process.Text = "Saving...";
                Application.DoEvents();
            }
            txtServerName.Enabled = bEnabled;
            txtDBName.Enabled = bEnabled;
            txtUser.Enabled = bEnabled;
            txtPassword.Enabled = bEnabled;
            txt_AccpacCompanyID.Enabled = bEnabled;
            txt_AccpacUserID.Enabled = bEnabled;
            txt_AccpacPwd.Enabled = bEnabled;
            txtAPIKey.Enabled = bEnabled;
            cmb_Retry.Enabled = bEnabled;
            txt_RetrialInterval.Enabled = bEnabled;
            txt_POUrl.Enabled = bEnabled;
            txt_OEUrl.Enabled = bEnabled;
            txt_ICUrl.Enabled = bEnabled;
            txt_WebUser.Enabled = bEnabled;
            btnSave.Enabled = bEnabled;
            btnClose.Enabled = bEnabled;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            AccpacLogOn objAccpacLogOn = new AccpacLogOn();
            string sError = string.Empty;
            int iNumOfRetry = 0;

            try
            {
                ControlEnabled(false);
                if (string.IsNullOrEmpty(txtServerName.Text.Trim()) ||
                string.IsNullOrEmpty(txtDBName.Text.Trim()) ||
                string.IsNullOrEmpty(txtUser.Text.Trim()) ||
                string.IsNullOrEmpty(txtPassword.Text) ||
                string.IsNullOrEmpty(txt_AccpacCompanyID.Text.Trim()) ||
                string.IsNullOrEmpty(txt_AccpacUserID.Text.Trim()) ||
                string.IsNullOrEmpty(txt_AccpacPwd.Text) ||
                string.IsNullOrEmpty(txtAPIKey.Text.Trim()) ||
                string.IsNullOrEmpty(cmb_Retry.Text.Trim()) ||
                string.IsNullOrEmpty(txt_RetrialInterval.Text.Trim()) ||
                string.IsNullOrEmpty(txt_POUrl.Text) ||
                string.IsNullOrEmpty(txt_OEUrl.Text.Trim()) ||
                string.IsNullOrEmpty(txt_ICUrl.Text.Trim()) ||
                string.IsNullOrEmpty(txt_WebUser.Text.Trim()))
                {
                    MessageBox.Show("Please fill out all the fields first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (int.TryParse(cmb_Retry.Text.Trim(), out iNumOfRetry))
                {
                    if (iNumOfRetry != 1 && iNumOfRetry != 3 && iNumOfRetry != 5)
                    {
                        MessageBox.Show("Numbers of Retry must be 1 or 3 or 5.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Numbers of Retry must be numeric.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (int.TryParse(txt_RetrialInterval.Text.Trim(), out iNumOfRetry))
                {
                    if (iNumOfRetry < 0  )
                    {
                        MessageBox.Show("Retrial Interval must be greater than 0.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Retrial Interval must be numeric.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (ValidateOpenSQL(txtServerName.Text.Trim(), txtDBName.Text.Trim(), txtUser.Text.Trim(), txtPassword.Text))
                {
                    sError = string.Empty;
                    if (CreateLogTables(txtServerName.Text.Trim(), txtDBName.Text.Trim(), txtUser.Text.Trim(), txtPassword.Text, out sError))
                    {

                    }
                    else
                    {
                        MessageBox.Show(sError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("SQL connection failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                sError = string.Empty;
                objAccpacLogOn.CurrVersion = publicVar.STR_ACCPAC_VERSION;
                objAccpacLogOn.CompanyID = txt_AccpacCompanyID.Text.Trim();
                objAccpacLogOn.UserID = txt_AccpacUserID.Text.Trim();
                objAccpacLogOn.Pwd = txt_AccpacPwd.Text;
                objAccpacLogOn.dtSessionDate = DateTime.Now;
                if (objAccpacLogOn.OpenSessionDBLink(out sError) == false)
                {
                    MessageBox.Show(sError.Trim(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                _strIniFile = Application.StartupPath + @"\" + publicVar.STR_SETTING_FILE_NAME;
                if (!File.Exists(_strIniFile))
                {
                    FileStream iniFile = File.Create(_strIniFile);
                    iniFile.Close();
                }
                _iniHelper = new INIHelper(_strIniFile);

                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_SERVER_CAPTION, TripleDESCryptography.DESEncrypt(txtServerName.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));//
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_DATABASE_CAPTION, TripleDESCryptography.DESEncrypt(txtDBName.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));//
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_USER_CAPTION, TripleDESCryptography.DESEncrypt(txtUser.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));//
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_PASSWORD_CAPTION, TripleDESCryptography.DESEncrypt(txtPassword.Text, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));//
                
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_ACCPAC_COMPANY_ID_CAPTION, TripleDESCryptography.DESEncrypt(txt_AccpacCompanyID.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_ACCPAC_USER_ID_CAPTION, TripleDESCryptography.DESEncrypt(txt_AccpacUserID.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_ACCPAC_PASSWORD_CAPTION, TripleDESCryptography.DESEncrypt(txt_AccpacPwd.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));
                
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_APIKEY_CAPTION, TripleDESCryptography.DESEncrypt(txtAPIKey.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_RETRY_COUNT_CAPTION, TripleDESCryptography.DESEncrypt(cmb_Retry.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_RETRIAL_INTERVAL_CAPTION, TripleDESCryptography.DESEncrypt(txt_RetrialInterval.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));

                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_URL_PO_CAPTION, TripleDESCryptography.DESEncrypt(txt_POUrl.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_URL_OE_CAPTION, TripleDESCryptography.DESEncrypt(txt_OEUrl.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_URL_IC_CAPTION, TripleDESCryptography.DESEncrypt(txt_ICUrl.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));
                _iniHelper.Write(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_USER_CAPTION, TripleDESCryptography.DESEncrypt(txt_WebUser.Text.Trim(), publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV));

                MessageBox.Show("Saved successfully.", this.Text.Trim(), MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString().Trim(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                objAccpacLogOn.CloseSession();
                ControlEnabled(true);
            }
        }

        private void cmb_Retry_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txt_RetrialInterval_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txt_RetrialInterval.Text.Trim().Length == 0)
            {
                if (e.KeyChar == 48)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (txt_RetrialInterval.SelectionStart == 0)
                {
                    if (e.KeyChar == 48)
                    {
                        e.Handled = true;
                    }
                }
            }
            if (!Char.IsNumber(e.KeyChar) && e.KeyChar != 8)
            {
                e.Handled = true;
            }
            if (e.KeyChar == 8)
            {
                txt_RetrialInterval.Text = string.Empty;
            }
        }
    }
}