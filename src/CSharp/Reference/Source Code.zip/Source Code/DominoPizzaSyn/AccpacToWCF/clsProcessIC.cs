﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using CommonTools;
using System.Data;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using AccpacBL;

namespace DominoPizzaSyn
{
    public static class clsProcessIC
    {
        public const string S_DATA_TITLE = "[";
        public const string S_DATA_FEET = "]";
        public const string S_RECORD_HEADER_TITLE = "{";
        public const string S_RECORD_HEADER_FEET = "},";

        public static void ReadICInt(string sConn, string sCompanyID, out List<clsLOGOICINT> lstRecord, out string sResult, out string sError)
        {
            string sSQL = string.Empty;
            DataTable tbICIntHD;
            DataTable tbICIntDtl;
            string sCreateTime = string.Empty;
            int iHdRecordConut = 0;
            int iDtlRecordCount = 0;
            clsLOGOICINT objLOGICInt;

            sResult = string.Empty;
            sError = string.Empty;
            lstRecord = new List<clsLOGOICINT>();

            try
            {
                DbTools.ConnectionString = sConn;
                if (DbTools.CheckConnection() == false)
                {
                    return;
                }
                
                sSQL = string.Empty;
                sSQL = sSQL + "SELECT * FROM( ";
                sSQL = sSQL + "SELECT ICICEH.SEQUENCENO, ICICEH.AUDTDATE, ICICEH.AUDTTIME, ICICEH.DOCNUM, ";
                sSQL = sSQL + "CASE WHEN LEN(LTRIM(RTRIM(GLAMF.ACCTID))) >= 3 THEN RIGHT(LTRIM(RTRIM(GLAMF.ACCTID)), 3) ELSE LTRIM(RTRIM(GLAMF.ACCTID)) END AS GLACCOUNT, ";
                sSQL = sSQL + "ICICEH.TRANSDATE, ";
                sSQL = sSQL + "LTRIM(LEFT(ICICEH.TRANSDATE, 4)) + '-' + LTRIM(LEFT(RIGHT(ICICEH.TRANSDATE, 4), 2)) + '-' + LTRIM(RIGHT(TRANSDATE, 2)) AS FMTEXPARRIVAL, ";
                sSQL = sSQL + "LTRIM(LEFT(ICICEH.AUDTDATE, 4)) + '-' + LTRIM(LEFT(RIGHT(ICICEH.AUDTDATE, 4), 2)) + '-' + LTRIM(RIGHT(ICICEH.AUDTDATE, 2)) AS FMTAUDTDATE, ";
                sSQL = sSQL + "CASE WHEN LEN(ICICEH.AUDTTIME) = 7 THEN ";
                sSQL = sSQL + "    CASE WHEN(LEFT(ICICEH.AUDTTIME, 1) + 8) >= 24 THEN LTRIM((LEFT(ICICEH.AUDTTIME, 1) + 8 - 24)) + ':' + LTRIM(LEFT(RIGHT(ICICEH.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(ICICEH.AUDTTIME, 4), 2)) ";
                sSQL = sSQL + "    ELSE LTRIM((LEFT(ICICEH.AUDTTIME, 1) + 8)) + ':' + LTRIM(LEFT(RIGHT(ICICEH.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(ICICEH.AUDTTIME, 4), 2)) END ";
                sSQL = sSQL + "WHEN LEN(ICICEH.AUDTDATE) = 8 THEN ";
                sSQL = sSQL + "    CASE WHEN(LEFT(ICICEH.AUDTTIME, 2) + 8) >= 24 THEN LTRIM((LEFT(ICICEH.AUDTTIME, 2) + 8 - 24)) + ':' + LTRIM(LEFT(RIGHT(ICICEH.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(ICICEH.AUDTTIME, 4), 2)) ";
                sSQL = sSQL + "    ELSE LTRIM((LEFT(ICICEH.AUDTTIME, 2) + 8)) + ':' + LTRIM(LEFT(RIGHT(ICICEH.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(ICICEH.AUDTTIME, 4), 2)) END ";
                sSQL = sSQL + "ELSE '00:00:00' END AS FMTAUDTTIME, ";
                sSQL = sSQL + "LOGICINT.SEQUENCENO AS LOGSEQUENCENO, LOGICINT.AUDTDATE AS LOGAUDTDATE, LOGICINT.AUDTTIME AS LOGAUDTTIME, LOGICINT.SYNSTATUS ";
                sSQL = sSQL + "FROM ICICEH WITH(INDEX(ICICEH_KEY_0)) ";
                sSQL = sSQL + "LEFT JOIN(SELECT DISTINCT SEQUENCENO, GLACCT FROM ICICED WITH(INDEX(ICICED_KEY_0))) AS ACCTTB ON ICICEH.SEQUENCENO = ACCTTB.SEQUENCENO ";
                sSQL = sSQL + "LEFT JOIN GLAMF WITH(INDEX(GLAMF_KEY_0)) ON ACCTTB.GLACCT = GLAMF.ACCTFMTTD ";
                sSQL = sSQL + "LEFT JOIN LOGICINT WITH(INDEX(PK_LOGICINT)) ON ICICEH.SEQUENCENO = LOGICINT.SEQUENCENO ";
                sSQL = sSQL + ") AS TMPTABLE_H ";
                sSQL = sSQL + "WHERE SYNSTATUS = " + publicVar.S_STATUS_NON_SYN + " OR LOGSEQUENCENO IS NULL OR AUDTDATE != LOGAUDTDATE OR AUDTTIME != LOGAUDTTIME";

                tbICIntHD = DbTools.GetDataTable(sSQL.Trim());

                if (tbICIntHD.Rows.Count > 0)
                {
                    iHdRecordConut = tbICIntHD.Rows.Count;
                    sResult = S_DATA_TITLE + Environment.NewLine;
                    for (int iHDCount = 0; iHDCount < iHdRecordConut; iHDCount++)
                    {
                        Application.DoEvents();
                        sResult = sResult + S_RECORD_HEADER_TITLE + Environment.NewLine;

                        sResult = sResult + @"""InternalUsageNo""" + @":""" + tbICIntHD.Rows[iHDCount][3].ToString().Trim() + @"""," + Environment.NewLine;                         sResult = sResult + @"""EmployerCode""" + @":""" + sCompanyID.Trim() + @"""," + Environment.NewLine;
                        sResult = sResult + @"""StoreID""" + @":""" + tbICIntHD.Rows[iHDCount][4].ToString().Trim() + @"""," + Environment.NewLine;
                        sResult = sResult + @"""ArrivalDate""" + @":""" + tbICIntHD.Rows[iHDCount][6].ToString().Trim() + @"""," + Environment.NewLine;

                        if (tbICIntHD.Rows[iHDCount][8].ToString().Trim().Length == 8)
                        {
                            sCreateTime = tbICIntHD.Rows[iHDCount][7].ToString().Trim() + " " + tbICIntHD.Rows[iHDCount][8].ToString().Trim();
                        }
                        else
                        {
                            sCreateTime = tbICIntHD.Rows[iHDCount][7].ToString().Trim() + " 0" + tbICIntHD.Rows[iHDCount][8].ToString().Trim();
                        }
                        sResult = sResult + @"""CreateTime""" + @":""" + sCreateTime.Trim() + @"""," + Environment.NewLine;

                        objLOGICInt = new clsLOGOICINT();
                        objLOGICInt.SEQUENCENO = tbICIntHD.Rows[iHDCount][0].ToString().Trim();
                        objLOGICInt.AUDTDATE = tbICIntHD.Rows[iHDCount][1].ToString().Trim();
                        objLOGICInt.AUDTTIME = tbICIntHD.Rows[iHDCount][2].ToString().Trim();
                        objLOGICInt.DOCNUM = tbICIntHD.Rows[iHDCount][3].ToString().Trim();
                        objLOGICInt.EMPLOYERCODE = sCompanyID.Trim();
                        objLOGICInt.STOREID = tbICIntHD.Rows[iHDCount][4].ToString().Trim();
                        objLOGICInt.ARRIVALDATE = tbICIntHD.Rows[iHDCount][6].ToString().Trim();
                        objLOGICInt.CREATEDATE = sCreateTime.Trim();
                        objLOGICInt.SYNSTATUS = publicVar.S_STATUS_SUCCEED_SYN;
                        lstRecord.Add(objLOGICInt);
                        objLOGICInt = null;

                        sResult = sResult + @"""Detail"":[" + Environment.NewLine;

                        sSQL = string.Empty;
                        sSQL = sSQL + "SELECT ROW_NUMBER() OVER(ORDER BY ICICED.SEQUENCENO) AS ROWNUM, ICICED.SEQUENCENO, ICICED.ITEMNO, ICICED.QUANTITY FROM ICICED WITH(INDEX(ICICED_KEY_0)) ";
                        sSQL = sSQL + "WHERE SEQUENCENO = " + tbICIntHD.Rows[iHDCount][0].ToString().Trim();
                        tbICIntDtl = DbTools.GetDataTable(sSQL.Trim());
                        if (tbICIntDtl.Rows.Count > 0)
                        {
                            iDtlRecordCount = tbICIntDtl.Rows.Count;

                            for (int iDtlCount = 0; iDtlCount < iDtlRecordCount; iDtlCount++)
                            {
                                Application.DoEvents();
                                sResult = sResult + "{" + Environment.NewLine;
                                sResult = sResult + @"""Index""" + @":" + tbICIntDtl.Rows[iDtlCount][0].ToString().Trim() + @"," + Environment.NewLine;
                                sResult = sResult + @"""ItemCode""" + @":""" + tbICIntDtl.Rows[iDtlCount][2].ToString().Trim() + @"""," + Environment.NewLine;
                                sResult = sResult + @"""Qty""" + @":" + Convert.ToDouble(tbICIntDtl.Rows[iDtlCount][3].ToString().Trim()).ToString("0.00") + Environment.NewLine;
                                if (iDtlCount + 1 == iDtlRecordCount)
                                {
                                    sResult = sResult + "}" + Environment.NewLine;
                                }
                                else
                                {
                                    sResult = sResult + "}," + Environment.NewLine;
                                }
                            }
                        }
                        sResult = sResult + @"]" + Environment.NewLine;
                        sResult = sResult + S_RECORD_HEADER_FEET + Environment.NewLine;
                    }
                    sResult = sResult + S_DATA_FEET;
                }
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();
            }
        }

        public static bool SynLOGICInt(string sConn, List<clsLOGOICINT> lstRecord, Dictionary<string, string> dicSucceed, out string sError)
        {
            sError = string.Empty;
            string sSQL = string.Empty;
            string sStatus = string.Empty;

            try
            {
                DbTools.ConnectionString = sConn;
                if (DbTools.CheckConnection() == false)
                {
                    sError = "Database connection failed.";
                    return false;
                }

                foreach (clsLOGOICINT objLOGICInt in lstRecord)
                {
                    Application.DoEvents();
                    if (dicSucceed.ContainsKey(objLOGICInt.DOCNUM.Trim()))
                    {
                        sStatus = publicVar.S_STATUS_SUCCEED_SYN.ToString().Trim();
                    }
                    else
                    {
                        sStatus = publicVar.S_STATUS_NON_SYN.ToString().Trim();
                    }
                    sSQL = "";
                    sSQL = sSQL + "IF EXISTS(SELECT * FROM LOGICINT WITH(INDEX(PK_LOGICINT)) WHERE SEQUENCENO=" + objLOGICInt.SEQUENCENO + ") ";
                    sSQL = sSQL + "    BEGIN";
                    sSQL = sSQL + "        UPDATE LOGICINT SET AUDTDATE = " + objLOGICInt.AUDTDATE + ", ";
                    sSQL = sSQL + "        AUDTTIME = " + objLOGICInt.AUDTTIME + ", ";
                    sSQL = sSQL + "        DOCNUM = '" + objLOGICInt.DOCNUM + "', ";
                    sSQL = sSQL + "        EMPLOYERCODE = '" + objLOGICInt.EMPLOYERCODE + "', ";
                    sSQL = sSQL + "        STOREID = '" + objLOGICInt.STOREID + "', ";
                    if (clsStartValid.IsDate(objLOGICInt.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + objLOGICInt.ARRIVALDATE + "', ";
                    }
                    else
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + "" + "', ";
                    }
                    sSQL = sSQL + "        CREATEDATE = '" + objLOGICInt.CREATEDATE + "', ";
                    sSQL = sSQL + "        SYNSTATUS = " + sStatus.Trim() + " WHERE SEQUENCENO=" + objLOGICInt.SEQUENCENO + " ";
                    sSQL = sSQL + "    END ";
                    sSQL = sSQL + "ELSE ";
                    sSQL = sSQL + "    BEGIN";
                    if (clsStartValid.IsDate(objLOGICInt.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        INSERT INTO LOGICINT(SEQUENCENO, AUDTDATE, AUDTTIME, DOCNUM, EMPLOYERCODE, STOREID, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGICInt.SEQUENCENO + ", " + objLOGICInt.AUDTDATE + ", " + objLOGICInt.AUDTTIME + ", '" + objLOGICInt.DOCNUM + "', '" + objLOGICInt.EMPLOYERCODE + "','" + objLOGICInt.STOREID + "', '" + objLOGICInt.ARRIVALDATE + "', '" + objLOGICInt.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    else
                    {
                        sSQL = sSQL + "        INSERT INTO LOGICINT(SEQUENCENO, AUDTDATE, AUDTTIME, DOCNUM, EMPLOYERCODE, STOREID, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGICInt.SEQUENCENO + ", " + objLOGICInt.AUDTDATE + ", " + objLOGICInt.AUDTTIME + ", '" + objLOGICInt.DOCNUM + "', '" + objLOGICInt.EMPLOYERCODE + "','" + objLOGICInt.STOREID + "', '" + "" + "', '" + objLOGICInt.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    sSQL = sSQL + "    END";
                    DbTools.ExecuteSql(sSQL.Trim());
                }
                return true;
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();
                return false;
            }

        }

        public static bool SynLOGICInt(string sConn, string sStatus, List<clsLOGOICINT> lstRecord, out string sError)
        {
            sError = string.Empty;
            string sSQL = string.Empty;

            try
            {
                DbTools.ConnectionString = sConn;
                if (DbTools.CheckConnection() == false)
                {
                    sError = "Database connection failed.";
                    return false;
                }

                foreach (clsLOGOICINT objLOGICInt in lstRecord)
                {
                    Application.DoEvents();
                    sSQL = "";
                    sSQL = sSQL + "IF EXISTS(SELECT * FROM LOGICINT WITH(INDEX(PK_LOGICINT)) WHERE SEQUENCENO=" + objLOGICInt.SEQUENCENO + ") ";
                    sSQL = sSQL + "    BEGIN";
                    sSQL = sSQL + "        UPDATE LOGICINT SET AUDTDATE = " + objLOGICInt.AUDTDATE + ", ";
                    sSQL = sSQL + "        AUDTTIME = " + objLOGICInt.AUDTTIME + ", ";
                    sSQL = sSQL + "        DOCNUM = '" + objLOGICInt.DOCNUM + "', ";
                    sSQL = sSQL + "        EMPLOYERCODE = '" + objLOGICInt.EMPLOYERCODE + "', ";
                    sSQL = sSQL + "        STOREID = '" + objLOGICInt.STOREID + "', ";
                    if (clsStartValid.IsDate(objLOGICInt.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + objLOGICInt.ARRIVALDATE + "', ";
                    }
                    else
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + "" + "', ";
                    }
                    sSQL = sSQL + "        CREATEDATE = '" + objLOGICInt.CREATEDATE + "', ";
                    sSQL = sSQL + "        SYNSTATUS = " + sStatus.Trim() + " WHERE SEQUENCENO=" + objLOGICInt.SEQUENCENO + " ";
                    sSQL = sSQL + "    END ";
                    sSQL = sSQL + "ELSE ";
                    sSQL = sSQL + "    BEGIN";
                    if (clsStartValid.IsDate(objLOGICInt.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        INSERT INTO LOGICINT(SEQUENCENO, AUDTDATE, AUDTTIME, DOCNUM, EMPLOYERCODE, STOREID, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGICInt.SEQUENCENO + ", " + objLOGICInt.AUDTDATE + ", " + objLOGICInt.AUDTTIME + ", '" + objLOGICInt.DOCNUM + "', '" + objLOGICInt.EMPLOYERCODE + "','" + objLOGICInt.STOREID + "', '" + objLOGICInt.ARRIVALDATE + "', '" + objLOGICInt.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    else
                    {
                        sSQL = sSQL + "        INSERT INTO LOGICINT(SEQUENCENO, AUDTDATE, AUDTTIME, DOCNUM, EMPLOYERCODE, STOREID, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGICInt.SEQUENCENO + ", " + objLOGICInt.AUDTDATE + ", " + objLOGICInt.AUDTTIME + ", '" + objLOGICInt.DOCNUM + "', '" + objLOGICInt.EMPLOYERCODE + "','" + objLOGICInt.STOREID + "', '" + "" + "', '" + objLOGICInt.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    sSQL = sSQL + "    END";
                    DbTools.ExecuteSql(sSQL.Trim());
                }
                return true;
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();
                return false;
            }
        }
    }
}
