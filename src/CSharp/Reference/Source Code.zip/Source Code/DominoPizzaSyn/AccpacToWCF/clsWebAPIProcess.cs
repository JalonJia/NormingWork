﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace DominoPizzaSyn
{
    public static class clsWebAPIProcess
    {
        public static bool HttpPost(string url, string body, out string sCode, out string sMessage, out string sData, out Dictionary<string, string> dicSucceed, out Dictionary<string, string> dicFailed)
        {
            string sRead = string.Empty;
            JObject joJsonCont;

            sCode = string.Empty;
            sMessage = string.Empty;
            sData = string.Empty;
            dicSucceed = new Dictionary<string, string>();
            dicFailed = new Dictionary<string, string>();

            try
            {
                Encoding encoding = Encoding.UTF8;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "POST";
                request.Accept = "text/html, application/xhtml+xml, *";
                request.ContentType = "application/json";
                byte[] buffer = encoding.GetBytes(body);
                request.ContentLength = buffer.Length;
                request.GetRequestStream().Write(buffer, 0, buffer.Length);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
                {
                    sRead = reader.ReadToEnd();

                    joJsonCont = (JObject)JsonConvert.DeserializeObject(sRead);
                    sCode = joJsonCont["retCode"].ToString();
                    sMessage = joJsonCont["retMsg"].ToString();
                    sData = joJsonCont["retData"].ToString();

                    #region
                    joJsonCont = (JObject)JsonConvert.DeserializeObject(sData);
                    if (joJsonCont.Property("成功") == null || joJsonCont.Property("成功").ToString() == "")
                    {
                    }
                    else
                    {
                        sData = joJsonCont["成功"].ToString().Replace("]", "").Replace("[", "").Replace(@"""", "").Replace("\n", "").Replace(" ", "").Replace("\t", "").Replace("\r", ""); ;

                        string[] sArray = sData.Split(',');
                        foreach (string sTranNum in sArray)
                        {
                            Application.DoEvents();
                            if (dicSucceed.ContainsKey(sTranNum.Trim()) == false)
                            {
                                dicSucceed.Add(sTranNum.Trim(), sTranNum.Trim());
                            }
                        }
                    }

                    if (joJsonCont.Property("上传失败") == null || joJsonCont.Property("上传失败").ToString() == "")
                    {
                    }
                    else
                    {
                        sMessage = sMessage + " - 上传失败";
                        sData = joJsonCont["上传失败"].ToString().Replace("]", "").Replace("[", "").Replace(@"""", "").Replace("\n", "").Replace(" ", "").Replace("\t", "").Replace("\r", ""); ;

                        string[] sArray = sData.Split(',');
                        foreach (string sTranNum in sArray)
                        {
                            Application.DoEvents();
                            if (dicFailed.ContainsKey(sTranNum.Trim()) == false)
                            {
                                dicFailed.Add(sTranNum.Trim(), sTranNum.Trim());
                            }
                        }
                    }

                    if (joJsonCont.Property("数据错误") == null || joJsonCont.Property("数据错误").ToString() == "")
                    {
                    }
                    else
                    {
                        sMessage = sMessage + " - 数据错误";
                        sData = joJsonCont["数据错误"].ToString().Replace("]", "").Replace("[", "").Replace(@"""", "").Replace("\n", "").Replace(" ", "").Replace("\t", "").Replace("\r", ""); ;

                        string[] sArray = sData.Split(',');
                        foreach (string sTranNum in sArray)
                        {
                            Application.DoEvents();
                            if (dicFailed.ContainsKey(sTranNum.Trim()) == false)
                            {
                                dicFailed.Add(sTranNum.Trim(), sTranNum.Trim());
                            }
                        }
                    }


                    if (joJsonCont.Property("单号重复") == null || joJsonCont.Property("单号重复").ToString() == "")
                    {
                    }
                    else
                    {
                        sMessage = sMessage + " - 单号重复";
                        sData = joJsonCont["单号重复"].ToString().Replace("]", "").Replace("[", "").Replace(@"""", "").Replace("\n", "").Replace(" ", "").Replace("\t", "").Replace("\r", ""); ;

                        string[] sArray = sData.Split(',');
                        foreach (string sTranNum in sArray)
                        {
                            Application.DoEvents();
                            if (dicSucceed.ContainsKey(sTranNum.Trim()) == false)
                            {
                                dicSucceed.Add(sTranNum.Trim(), sTranNum.Trim());
                            }

                            Application.DoEvents();
                            if (dicFailed.ContainsKey(sTranNum.Trim()) == false)
                            {
                                dicFailed.Add(sTranNum.Trim(), sTranNum.Trim());
                            }
                        }
                    }
                    #endregion
                }
                if (sCode == "0")
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                sMessage = ex.Message.ToString().Trim();
                return false;
            }
        }

    }
}
