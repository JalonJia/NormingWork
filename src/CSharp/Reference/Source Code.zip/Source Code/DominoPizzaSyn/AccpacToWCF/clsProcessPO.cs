﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using CommonTools;
using System.Data;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using AccpacBL;

namespace DominoPizzaSyn
{
    public static class clsProcessPO
    {
        public const string S_DATA_TITLE = "[";
        public const string S_DATA_FEET = "]";
        public const string S_RECORD_HEADER_TITLE = "{";
        public const string S_RECORD_HEADER_FEET = "},";

        public static void ReadPOOrder(string sConn, string sCompanyID, out List<clsLOGPOORD> lstRecord, out string sResult, out string sError)
        {
            string sSQL = string.Empty;
            DataTable tbPOOrderHD;
            DataTable tbPOOrderDtl;
            string sCreateTime = string.Empty;
            int iHdRecordConut = 0;
            int iDtlRecordCount = 0;
            clsLOGPOORD objLOGPOORD;

            sResult = string.Empty;
            sError = string.Empty;
            lstRecord = new List<clsLOGPOORD>();

            try
            {
                DbTools.ConnectionString = sConn;
                if (DbTools.CheckConnection() == false)
                {
                    return;
                }

                sSQL = string.Empty;
                sSQL = sSQL + "SELECT * FROM( ";
                sSQL = sSQL + "SELECT POPORH1.PORHSEQ, POPORH1.AUDTDATE, POPORH1.AUDTTIME, POPORH1.PONUMBER, POPORH1.VDCODE, POPORH1.EXPARRIVAL, ";
                sSQL = sSQL + "LTRIM(LEFT(POPORH1.EXPARRIVAL, 4)) + '-' + LTRIM(LEFT(RIGHT(POPORH1.EXPARRIVAL, 4), 2)) + '-' + LTRIM(RIGHT(EXPARRIVAL, 2)) AS FMTEXPARRIVAL, ";
                sSQL = sSQL + "    LTRIM(LEFT(POPORH1.AUDTDATE, 4)) + '-' + LTRIM(LEFT(RIGHT(POPORH1.AUDTDATE, 4), 2)) + '-' + LTRIM(RIGHT(POPORH1.AUDTDATE, 2)) AS FMTAUDTDATE, ";
                sSQL = sSQL + "    CASE WHEN LEN(POPORH1.AUDTTIME) = 7 THEN ";
                sSQL = sSQL + "        CASE WHEN(LEFT(POPORH1.AUDTTIME, 1) + 8) >= 24 THEN LTRIM((LEFT(POPORH1.AUDTTIME, 1) + 8 - 24)) + ':' + LTRIM(LEFT(RIGHT(POPORH1.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(POPORH1.AUDTTIME, 4), 2)) ";
                sSQL = sSQL + "        ELSE LTRIM((LEFT(POPORH1.AUDTTIME, 1) + 8)) + ':' + LTRIM(LEFT(RIGHT(POPORH1.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(POPORH1.AUDTTIME, 4), 2)) END ";
                sSQL = sSQL + "    WHEN LEN(POPORH1.AUDTDATE) = 8 THEN ";
                sSQL = sSQL + "        CASE WHEN(LEFT(POPORH1.AUDTTIME, 2) + 8) >= 24 THEN LTRIM((LEFT(POPORH1.AUDTTIME, 2) + 8 - 24)) + ':' + LTRIM(LEFT(RIGHT(POPORH1.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(POPORH1.AUDTTIME, 4), 2)) ";
                sSQL = sSQL + "        ELSE LTRIM((LEFT(POPORH1.AUDTTIME, 2) + 8)) + ':' + LTRIM(LEFT(RIGHT(POPORH1.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(POPORH1.AUDTTIME, 4), 2)) END ";
                sSQL = sSQL + "    ELSE '00:00:00' END AS FMTAUDTTIME, ";
                sSQL = sSQL + "    CASE WHEN POPORH1.ONHOLD = 0 THEN 1 ELSE 9 END AS DELFLAG, ";
                sSQL = sSQL + "    LOGPOORD.PORHSEQ AS LOGPORHSEQ, LOGPOORD.AUDTDATE AS LOGAUDTDATE, LOGPOORD.AUDTTIME AS LOGAUDTTIME, LOGPOORD.SYNSTATUS ";
                sSQL = sSQL + "    FROM POPORH1 WITH(INDEX(POPORH1_KEY_0)) ";
                sSQL = sSQL + "    LEFT JOIN LOGPOORD WITH(INDEX(PK_LOGPOORD)) ON POPORH1.PORHSEQ = LOGPOORD.PORHSEQ ";
                sSQL = sSQL + ") AS TMPTABLE_H ";
                sSQL = sSQL + "WHERE SYNSTATUS = " + publicVar.S_STATUS_NON_SYN + " OR LOGPORHSEQ IS NULL OR AUDTDATE != LOGAUDTDATE OR AUDTTIME != LOGAUDTTIME";

                tbPOOrderHD = DbTools.GetDataTable(sSQL.Trim());

                if (tbPOOrderHD.Rows.Count > 0)
                {
                    iHdRecordConut = tbPOOrderHD.Rows.Count;
                    sResult = S_DATA_TITLE + Environment.NewLine;
                    for (int iHDCount = 0; iHDCount < iHdRecordConut; iHDCount++)
                    {
                        Application.DoEvents();

                        sResult = sResult + S_RECORD_HEADER_TITLE + Environment.NewLine;

                        sResult = sResult + @"""PurchaseOrderNo""" + @":""" + tbPOOrderHD.Rows[iHDCount][3].ToString().Trim() + @"""," + Environment.NewLine;
                        sResult = sResult + @"""EmployerCode""" + @":""" + sCompanyID.Trim() + @"""," + Environment.NewLine;
                        sResult = sResult + @"""VendorNo""" + @":""" + tbPOOrderHD.Rows[iHDCount][4].ToString().Trim() + @"""," + Environment.NewLine;
                        sResult = sResult + @"""ArrivalDate""" + @":""" + tbPOOrderHD.Rows[iHDCount][6].ToString().Trim() + @"""," + Environment.NewLine;

                        if (tbPOOrderHD.Rows[iHDCount][8].ToString().Trim().Length == 8)
                        {
                            sCreateTime = tbPOOrderHD.Rows[iHDCount][7].ToString().Trim() + " " + tbPOOrderHD.Rows[iHDCount][8].ToString().Trim();
                        }
                        else
                        {
                            sCreateTime = tbPOOrderHD.Rows[iHDCount][7].ToString().Trim() + " 0" + tbPOOrderHD.Rows[iHDCount][8].ToString().Trim();
                        }
                        sResult = sResult + @"""CreateTime""" + @":""" + sCreateTime.Trim() + @"""," + Environment.NewLine;

                        sResult = sResult + @"""Status""" + @":" + tbPOOrderHD.Rows[iHDCount][9].ToString().Trim() + @"," + Environment.NewLine;

                        objLOGPOORD = new clsLOGPOORD();
                        objLOGPOORD.PORHSEQ = tbPOOrderHD.Rows[iHDCount][0].ToString().Trim();
                        objLOGPOORD.AUDTDATE = tbPOOrderHD.Rows[iHDCount][1].ToString().Trim();
                        objLOGPOORD.AUDTTIME = tbPOOrderHD.Rows[iHDCount][2].ToString().Trim();
                        objLOGPOORD.PONUMBER = tbPOOrderHD.Rows[iHDCount][3].ToString().Trim();
                        objLOGPOORD.EMPLOYERCODE = sCompanyID.Trim();
                        objLOGPOORD.VDCODE = tbPOOrderHD.Rows[iHDCount][4].ToString().Trim();
                        objLOGPOORD.ARRIVALDATE = tbPOOrderHD.Rows[iHDCount][6].ToString().Trim();
                        objLOGPOORD.CREATEDATE = sCreateTime.Trim();
                        objLOGPOORD.SYNSTATUS = publicVar.S_STATUS_SUCCEED_SYN;
                        lstRecord.Add(objLOGPOORD);
                        objLOGPOORD = null;

                        sResult = sResult + @"""Detail"":[" + Environment.NewLine;

                        sSQL = string.Empty;
                        sSQL = sSQL + "SELECT ROW_NUMBER() OVER(ORDER BY POPORL.PORHSEQ) AS ROWNUM, POPORL.PORHSEQ, POPORL.ITEMNO, POPORL.OQORDERED FROM POPORL WITH(INDEX(POPORL_KEY_0)) ";
                        sSQL = sSQL + "WHERE PORHSEQ = " + tbPOOrderHD.Rows[iHDCount][0].ToString().Trim();
                        tbPOOrderDtl = DbTools.GetDataTable(sSQL.Trim());
                        if (tbPOOrderDtl.Rows.Count > 0)
                        {
                            iDtlRecordCount = tbPOOrderDtl.Rows.Count;

                            for (int iDtlCount = 0; iDtlCount < iDtlRecordCount; iDtlCount++)
                            {
                                Application.DoEvents();
                                sResult = sResult + "{" + Environment.NewLine;
                                sResult = sResult + @"""Index""" + @":" + tbPOOrderDtl.Rows[iDtlCount][0].ToString().Trim() + @"," + Environment.NewLine;
                                sResult = sResult + @"""ItemCode""" + @":""" + tbPOOrderDtl.Rows[iDtlCount][2].ToString().Trim() + @"""," + Environment.NewLine;
                                sResult = sResult + @"""Qty""" + @":" + Convert.ToDouble(tbPOOrderDtl.Rows[iDtlCount][3].ToString().Trim()).ToString("0.00") + Environment.NewLine;
                                if (iDtlCount + 1 == iDtlRecordCount)
                                {
                                    sResult = sResult + "}" + Environment.NewLine;
                                }
                                else
                                {
                                    sResult = sResult + "}," + Environment.NewLine;
                                }
                            }
                        }
                        sResult = sResult + @"]" + Environment.NewLine;
                        sResult = sResult + S_RECORD_HEADER_FEET + Environment.NewLine;
                    }
                    sResult = sResult + S_DATA_FEET;
                }
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();
            }
        }
        
        public static bool SynLOGPOOrder(string sConn,  List<clsLOGPOORD> lstRecord, Dictionary<string, string> dicSucceed,  out string sError)
        {
            sError = string.Empty;
            string sSQL = string.Empty;
            string sStatus = string.Empty;

            try
            {
                DbTools.ConnectionString = sConn;
                if (DbTools.CheckConnection() == false)
                {
                    sError = "Database connection failed.";
                    return false ;
                }

                foreach (clsLOGPOORD objLOGPOORD in lstRecord)
                {
                    Application.DoEvents();
                    if (dicSucceed.ContainsKey(objLOGPOORD.PONUMBER.Trim()))
                    {
                        sStatus = publicVar.S_STATUS_SUCCEED_SYN.ToString().Trim();
                    }
                    else
                    {
                        sStatus = publicVar.S_STATUS_NON_SYN.ToString().Trim();
                    }
                    sSQL = "";
                    sSQL = sSQL + "IF EXISTS(SELECT * FROM LOGPOORD WITH(INDEX(PK_LOGPOORD)) WHERE PORHSEQ=" + objLOGPOORD.PORHSEQ + ") ";
                    sSQL = sSQL + "    BEGIN";
                    sSQL = sSQL + "        UPDATE LOGPOORD SET AUDTDATE = " + objLOGPOORD.AUDTDATE + ", ";
                    sSQL = sSQL + "        AUDTTIME = " + objLOGPOORD.AUDTTIME + ", ";
                    sSQL = sSQL + "        PONUMBER = '" + objLOGPOORD.PONUMBER + "', ";
                    sSQL = sSQL + "        EMPLOYERCODE = '" + objLOGPOORD.EMPLOYERCODE + "', ";
                    sSQL = sSQL + "        VDCODE = '" + objLOGPOORD.VDCODE + "', ";
                    if (clsStartValid.IsDate(objLOGPOORD.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + objLOGPOORD.ARRIVALDATE + "', ";
                    }
                    else
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + "" + "', ";
                    }
                    sSQL = sSQL + "        CREATEDATE = '" + objLOGPOORD.CREATEDATE + "', ";
                    sSQL = sSQL + "        SYNSTATUS = " + sStatus.Trim() + " WHERE PORHSEQ=" + objLOGPOORD.PORHSEQ + " ";
                    sSQL = sSQL + "    END ";
                    sSQL = sSQL + "ELSE ";
                    sSQL = sSQL + "    BEGIN";
                    if (clsStartValid.IsDate(objLOGPOORD.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        INSERT INTO LOGPOORD(PORHSEQ, AUDTDATE, AUDTTIME, PONUMBER, EMPLOYERCODE, VDCODE, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGPOORD.PORHSEQ + ", " + objLOGPOORD.AUDTDATE + ", " + objLOGPOORD.AUDTTIME + ", '" + objLOGPOORD.PONUMBER + "', '" + objLOGPOORD.EMPLOYERCODE + "','" + objLOGPOORD.VDCODE + "', '" + objLOGPOORD.ARRIVALDATE + "', '" + objLOGPOORD.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    else
                    {
                        sSQL = sSQL + "        INSERT INTO LOGPOORD(PORHSEQ, AUDTDATE, AUDTTIME, PONUMBER, EMPLOYERCODE, VDCODE, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGPOORD.PORHSEQ + ", " + objLOGPOORD.AUDTDATE + ", " + objLOGPOORD.AUDTTIME + ", '" + objLOGPOORD.PONUMBER + "', '" + objLOGPOORD.EMPLOYERCODE + "','" + objLOGPOORD.VDCODE + "', '" + "" + "', '" + objLOGPOORD.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    sSQL = sSQL + "    END";
                    DbTools.ExecuteSql(sSQL.Trim());
                }                
                return true;
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();
                return false;
            }
        }

        public static bool SynLOGPOOrder(string sConn, string sStatus, List<clsLOGPOORD> lstRecord, out string sError)
        {
            sError = string.Empty;
            string sSQL = string.Empty;
            
            try
            {
                DbTools.ConnectionString = sConn;
                if (DbTools.CheckConnection() == false)
                {
                    sError = "Database connection failed.";
                    return false;
                }

                foreach (clsLOGPOORD objLOGPOORD in lstRecord)
                {
                    Application.DoEvents();
                    sSQL = "";
                    sSQL = sSQL + "IF EXISTS(SELECT * FROM LOGPOORD WITH(INDEX(PK_LOGPOORD)) WHERE PORHSEQ=" + objLOGPOORD.PORHSEQ + ") ";
                    sSQL = sSQL + "    BEGIN";
                    sSQL = sSQL + "        UPDATE LOGPOORD SET AUDTDATE = " + objLOGPOORD.AUDTDATE + ", ";
                    sSQL = sSQL + "        AUDTTIME = " + objLOGPOORD.AUDTTIME + ", ";
                    sSQL = sSQL + "        PONUMBER = '" + objLOGPOORD.PONUMBER + "', ";
                    sSQL = sSQL + "        EMPLOYERCODE = '" + objLOGPOORD.EMPLOYERCODE + "', ";
                    sSQL = sSQL + "        VDCODE = '" + objLOGPOORD.VDCODE + "', ";
                    if (clsStartValid.IsDate(objLOGPOORD.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + objLOGPOORD.ARRIVALDATE + "', ";
                    }
                    else
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + "" + "', ";
                    }
                    sSQL = sSQL + "        CREATEDATE = '" + objLOGPOORD.CREATEDATE + "', ";
                    sSQL = sSQL + "        SYNSTATUS = " + sStatus.Trim() + " WHERE PORHSEQ=" + objLOGPOORD.PORHSEQ + " ";
                    sSQL = sSQL + "    END ";
                    sSQL = sSQL + "ELSE ";
                    sSQL = sSQL + "    BEGIN";
                    if (clsStartValid.IsDate(objLOGPOORD.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        INSERT INTO LOGPOORD(PORHSEQ, AUDTDATE, AUDTTIME, PONUMBER, EMPLOYERCODE, VDCODE, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGPOORD.PORHSEQ + ", " + objLOGPOORD.AUDTDATE + ", " + objLOGPOORD.AUDTTIME + ", '" + objLOGPOORD.PONUMBER + "', '" + objLOGPOORD.EMPLOYERCODE + "','" + objLOGPOORD.VDCODE + "', '" + objLOGPOORD.ARRIVALDATE + "', '" + objLOGPOORD.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    else
                    {
                        sSQL = sSQL + "        INSERT INTO LOGPOORD(PORHSEQ, AUDTDATE, AUDTTIME, PONUMBER, EMPLOYERCODE, VDCODE, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGPOORD.PORHSEQ + ", " + objLOGPOORD.AUDTDATE + ", " + objLOGPOORD.AUDTTIME + ", '" + objLOGPOORD.PONUMBER + "', '" + objLOGPOORD.EMPLOYERCODE + "','" + objLOGPOORD.VDCODE + "', '" + "" + "', '" + objLOGPOORD.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    sSQL = sSQL + "    END";
                    DbTools.ExecuteSql(sSQL.Trim());
                }
                return true;
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();
                return false;
            }
        }

    }
}
