﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using CommonTools;
using System.Data;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using AccpacBL;

namespace DominoPizzaSyn
{
    public static class clsProcessOE
    {
        public const string S_DATA_TITLE = "[";
        public const string S_DATA_FEET = "]";
        public const string S_RECORD_HEADER_TITLE = "{";
        public const string S_RECORD_HEADER_FEET = "},";

        public static void ReadOEShip(string sConn, string sCompanyID, out List<clsLOGOESHIP> lstRecord, out string sResult, out string sError)
        {
            string sSQL = string.Empty;
            DataTable tbOEShipHD;
            DataTable tbOEShipDtl;
            string sCreateTime = string.Empty;
            int iHdRecordConut = 0;
            int iDtlRecordCount = 0;
            clsLOGOESHIP objLOGOESHP;

            sResult = string.Empty;
            sError = string.Empty;
            lstRecord = new List<clsLOGOESHIP>();

            try
            {
                DbTools.ConnectionString = sConn;
                if (DbTools.CheckConnection() == false)
                {
                    return;
                }

                sSQL = string.Empty;
                sSQL = sSQL + "SELECT* FROM( ";
                sSQL = sSQL + "SELECT OESHIH.SHIUNIQ, OESHIH.AUDTDATE, OESHIH.AUDTTIME, OESHIH.SHINUMBER, OESHIH.CUSTOMER, OESHIH.EXPDATE, ";
                sSQL = sSQL + "LTRIM(LEFT(OESHIH.EXPDATE, 4)) + '-' + LTRIM(LEFT(RIGHT(OESHIH.EXPDATE, 4), 2)) + '-' + LTRIM(RIGHT(EXPDATE, 2)) AS FMTEXPARRIVAL, ";
                sSQL = sSQL + "LTRIM(LEFT(OESHIH.AUDTDATE, 4)) + '-' + LTRIM(LEFT(RIGHT(OESHIH.AUDTDATE, 4), 2)) + '-' + LTRIM(RIGHT(OESHIH.AUDTDATE, 2)) AS FMTAUDTDATE, ";
                sSQL = sSQL + "CASE WHEN LEN(OESHIH.AUDTTIME) = 7 THEN ";
                sSQL = sSQL + "    CASE WHEN(LEFT(OESHIH.AUDTTIME, 1) + 8) >= 24 THEN LTRIM((LEFT(OESHIH.AUDTTIME, 1) + 8 - 24)) + ':' + LTRIM(LEFT(RIGHT(OESHIH.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(OESHIH.AUDTTIME, 4), 2)) ";
                sSQL = sSQL + "    ELSE LTRIM((LEFT(OESHIH.AUDTTIME, 1) + 8)) + ':' + LTRIM(LEFT(RIGHT(OESHIH.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(OESHIH.AUDTTIME, 4), 2)) END ";
                sSQL = sSQL + "WHEN LEN(OESHIH.AUDTDATE) = 8 THEN ";
                sSQL = sSQL + "    CASE WHEN(LEFT(OESHIH.AUDTTIME, 2) + 8) >= 24 THEN LTRIM((LEFT(OESHIH.AUDTTIME, 2) + 8 - 24)) + ':' + LTRIM(LEFT(RIGHT(OESHIH.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(OESHIH.AUDTTIME, 4), 2)) ";
                sSQL = sSQL + "    ELSE LTRIM((LEFT(OESHIH.AUDTTIME, 2) + 8)) + ':' + LTRIM(LEFT(RIGHT(OESHIH.AUDTTIME, 6), 2)) + ':' + LTRIM(LEFT(RIGHT(OESHIH.AUDTTIME, 4), 2)) END ";
                sSQL = sSQL + "ELSE '00:00:00' END AS FMTAUDTTIME, ";
                sSQL = sSQL + "LOGOESHP.SHIUNIQ AS LOGSHIUNIQ, LOGOESHP.AUDTDATE AS LOGAUDTDATE, LOGOESHP.AUDTTIME AS LOGAUDTTIME, LOGOESHP.SYNSTATUS ";
                sSQL = sSQL + "FROM OESHIH WITH(INDEX(OESHIH_KEY_0)) ";
                sSQL = sSQL + "LEFT JOIN LOGOESHP WITH(INDEX(PK_LOGOESHP)) ON OESHIH.SHIUNIQ = LOGOESHP.SHIUNIQ ";
                sSQL = sSQL + ") AS TMPTABLE_H ";
                sSQL = sSQL + "WHERE SYNSTATUS = " + publicVar.S_STATUS_NON_SYN + " OR LOGSHIUNIQ IS NULL OR AUDTDATE != LOGAUDTDATE OR AUDTTIME != LOGAUDTTIME";

                tbOEShipHD = DbTools.GetDataTable(sSQL.Trim());

                if (tbOEShipHD.Rows.Count > 0)
                {
                    iHdRecordConut = tbOEShipHD.Rows.Count;
                    sResult = S_DATA_TITLE + Environment.NewLine;
                    for (int iHDCount = 0; iHDCount < iHdRecordConut; iHDCount++)
                    {
                        Application.DoEvents();
                        sResult = sResult + S_RECORD_HEADER_TITLE + Environment.NewLine;

                        sResult = sResult + @"""DeliveryNoteNo""" + @":""" + tbOEShipHD.Rows[iHDCount][3].ToString().Trim() + @"""," + Environment.NewLine;                         sResult = sResult + @"""EmployerCode""" + @":""" + sCompanyID.Trim() + @"""," + Environment.NewLine;
                        sResult = sResult + @"""StoreID""" + @":""" + tbOEShipHD.Rows[iHDCount][4].ToString().Trim() + @"""," + Environment.NewLine;
                        sResult = sResult + @"""ArrivalDate""" + @":""" + tbOEShipHD.Rows[iHDCount][6].ToString().Trim() + @"""," + Environment.NewLine;

                        if (tbOEShipHD.Rows[iHDCount][8].ToString().Trim().Length == 8)
                        {
                            sCreateTime = tbOEShipHD.Rows[iHDCount][7].ToString().Trim() + " " + tbOEShipHD.Rows[iHDCount][8].ToString().Trim();
                        }
                        else
                        {
                            sCreateTime = tbOEShipHD.Rows[iHDCount][7].ToString().Trim() + " 0" + tbOEShipHD.Rows[iHDCount][8].ToString().Trim();
                        }
                        sResult = sResult + @"""CreateTime""" + @":""" + sCreateTime.Trim() + @"""," + Environment.NewLine;

                        objLOGOESHP = new clsLOGOESHIP();
                        objLOGOESHP.SHIUNIQ = tbOEShipHD.Rows[iHDCount][0].ToString().Trim();
                        objLOGOESHP.AUDTDATE = tbOEShipHD.Rows[iHDCount][1].ToString().Trim();
                        objLOGOESHP.AUDTTIME = tbOEShipHD.Rows[iHDCount][2].ToString().Trim();
                        objLOGOESHP.SHINUMBER = tbOEShipHD.Rows[iHDCount][3].ToString().Trim();
                        objLOGOESHP.EMPLOYERCODE = sCompanyID.Trim();
                        objLOGOESHP.IDCUST = tbOEShipHD.Rows[iHDCount][4].ToString().Trim();
                        objLOGOESHP.ARRIVALDATE = tbOEShipHD.Rows[iHDCount][6].ToString().Trim();
                        objLOGOESHP.CREATEDATE = sCreateTime.Trim();
                        objLOGOESHP.SYNSTATUS = publicVar.S_STATUS_SUCCEED_SYN;
                        lstRecord.Add(objLOGOESHP);
                        objLOGOESHP = null;

                        sResult = sResult + @"""Detail"":[" + Environment.NewLine;

                        sSQL = string.Empty;
                        sSQL = sSQL + "SELECT ROW_NUMBER() OVER(ORDER BY OESHID.SHIUNIQ) AS ROWNUM, OESHID.SHIUNIQ, OESHID.ITEM, OESHID.QTYSHIPPED, ";
                        sSQL = sSQL + "CASE WHEN OESHIDL.LOTNUMF IS NULL THEN '' ELSE OESHIDL.LOTNUMF END AS LOTSERNUM, ";
                        sSQL = sSQL + "CASE WHEN OESHIDL.QTY IS NULL THEN 0 ELSE OESHIDL.QTY END LOTSERQTY ";
                        sSQL = sSQL + "FROM OESHID WITH(INDEX(OESHID_KEY_0)) ";
                        sSQL = sSQL + "LEFT JOIN OESHIDL WITH(INDEX(OESHIDL_KEY_0)) ON OESHID.SHIUNIQ = OESHIDL.SHIUNIQ AND OESHID.LINENUM = OESHIDL.LINENUM ";
                        sSQL = sSQL + "WHERE OESHID.SHIUNIQ = " + tbOEShipHD.Rows[iHDCount][0].ToString().Trim();
                        tbOEShipDtl = DbTools.GetDataTable(sSQL.Trim());
                        if (tbOEShipDtl.Rows.Count > 0)
                        {
                            iDtlRecordCount = tbOEShipDtl.Rows.Count;

                            for (int iDtlCount = 0; iDtlCount < iDtlRecordCount; iDtlCount++)
                            {
                                Application.DoEvents();
                                sResult = sResult + "{" + Environment.NewLine;
                                sResult = sResult + @"""Index""" + @":" + tbOEShipDtl.Rows[iDtlCount][0].ToString().Trim() + @"," + Environment.NewLine;
                                sResult = sResult + @"""ItemCode""" + @":""" + tbOEShipDtl.Rows[iDtlCount][2].ToString().Trim() + @"""," + Environment.NewLine;
                                sResult = sResult + @"""Qty""" + @":" + Convert.ToDouble(tbOEShipDtl.Rows[iDtlCount][3].ToString().Trim()).ToString("0.00") + @"," + Environment.NewLine;
                                sResult = sResult + @"""LotNumber""" + @":""" + tbOEShipDtl.Rows[iDtlCount][4].ToString().Trim() + @"""," + Environment.NewLine;
                                sResult = sResult + @"""LotQty""" + @":" + Convert.ToDouble(tbOEShipDtl.Rows[iDtlCount][5].ToString().Trim()).ToString("0.00") + Environment.NewLine;
                                if (iDtlCount + 1 == iDtlRecordCount)
                                {

                                    sResult = sResult + "}" + Environment.NewLine;
                                }
                                else
                                {
                                    sResult = sResult + "}," + Environment.NewLine;
                                }
                            }
                        }
                        sResult = sResult + @"]" + Environment.NewLine;
                        sResult = sResult + S_RECORD_HEADER_FEET + Environment.NewLine;
                    }
                    sResult = sResult + S_DATA_FEET;
                }
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();
            }
        }

        public static bool SynLOGOEShip(string sConn, List<clsLOGOESHIP> lstRecord, Dictionary<string, string> dicSucceed, out string sError)
        {
            sError = string.Empty;
            string sSQL = string.Empty;
            string sStatus = string.Empty;

            try
            {
                DbTools.ConnectionString = sConn;
                if (DbTools.CheckConnection() == false)
                {
                    sError = "Database connection failed.";
                    return false;
                }

                foreach (clsLOGOESHIP objLOGOESHP in lstRecord)
                {
                    Application.DoEvents();
                    if (dicSucceed.ContainsKey(objLOGOESHP.SHINUMBER.Trim()))
                    {
                        sStatus = publicVar.S_STATUS_SUCCEED_SYN.ToString().Trim();
                    }
                    else
                    {
                        sStatus = publicVar.S_STATUS_NON_SYN.ToString().Trim();
                    }
                    sSQL = "";
                    sSQL = sSQL + "IF EXISTS(SELECT * FROM LOGOESHP WITH(INDEX(PK_LOGOESHP)) WHERE SHIUNIQ=" + objLOGOESHP.SHIUNIQ + ") ";
                    sSQL = sSQL + "    BEGIN";
                    sSQL = sSQL + "        UPDATE LOGOESHP SET AUDTDATE = " + objLOGOESHP.AUDTDATE + ", ";
                    sSQL = sSQL + "        AUDTTIME = " + objLOGOESHP.AUDTTIME + ", ";
                    sSQL = sSQL + "        SHINUMBER = '" + objLOGOESHP.SHINUMBER + "', ";
                    sSQL = sSQL + "        EMPLOYERCODE = '" + objLOGOESHP.EMPLOYERCODE + "', ";
                    sSQL = sSQL + "        STOREID = '" + objLOGOESHP.IDCUST + "', ";
                    sSQL = sSQL + "        IDCUST = '" + objLOGOESHP.IDCUST + "', ";
                    if (clsStartValid.IsDate(objLOGOESHP.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + objLOGOESHP.ARRIVALDATE + "', ";
                    }
                    else
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + "" + "', ";
                    }
                    sSQL = sSQL + "        CREATEDATE = '" + objLOGOESHP.CREATEDATE + "', ";
                    sSQL = sSQL + "        SYNSTATUS = " + sStatus.Trim() + " WHERE SHIUNIQ=" + objLOGOESHP.SHIUNIQ + " ";
                    sSQL = sSQL + "    END ";
                    sSQL = sSQL + "ELSE ";
                    sSQL = sSQL + "    BEGIN";
                    if (clsStartValid.IsDate(objLOGOESHP.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        INSERT INTO LOGOESHP(SHIUNIQ, AUDTDATE, AUDTTIME, SHINUMBER, EMPLOYERCODE, STOREID, IDCUST, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGOESHP.SHIUNIQ + ", " + objLOGOESHP.AUDTDATE + ", " + objLOGOESHP.AUDTTIME + ", '" + objLOGOESHP.SHINUMBER + "', '" + objLOGOESHP.EMPLOYERCODE + "','" + objLOGOESHP.IDCUST + "','" + objLOGOESHP.IDCUST + "', '" + objLOGOESHP.ARRIVALDATE + "', '" + objLOGOESHP.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    else
                    {
                        sSQL = sSQL + "        INSERT INTO LOGOESHP(SHIUNIQ, AUDTDATE, AUDTTIME, SHINUMBER, EMPLOYERCODE, STOREID, IDCUST, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGOESHP.SHIUNIQ + ", " + objLOGOESHP.AUDTDATE + ", " + objLOGOESHP.AUDTTIME + ", '" + objLOGOESHP.SHINUMBER + "', '" + objLOGOESHP.EMPLOYERCODE + "','" + objLOGOESHP.IDCUST + "','" + objLOGOESHP.IDCUST + "', '" + "" + "', '" + objLOGOESHP.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    sSQL = sSQL + "    END";
                    DbTools.ExecuteSql(sSQL.Trim());
                }
                return true;
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();
                return false;
            }

        }

        public static bool SynLOGOEShip(string sConn, string sStatus, List<clsLOGOESHIP> lstRecord, out string sError)
        {
            sError = string.Empty;
            string sSQL = string.Empty;

            try
            {
                DbTools.ConnectionString = sConn;
                if (DbTools.CheckConnection() == false)
                {
                    sError = "Database connection failed.";
                    return false;
                }

                foreach (clsLOGOESHIP objLOGOESHP in lstRecord)
                {
                    Application.DoEvents();
                    sSQL = "";
                    sSQL = sSQL + "IF EXISTS(SELECT * FROM LOGOESHP WITH(INDEX(PK_LOGOESHP)) WHERE SHIUNIQ=" + objLOGOESHP.SHIUNIQ + ") ";
                    sSQL = sSQL + "    BEGIN";
                    sSQL = sSQL + "        UPDATE LOGOESHP SET AUDTDATE = " + objLOGOESHP.AUDTDATE + ", ";
                    sSQL = sSQL + "        AUDTTIME = " + objLOGOESHP.AUDTTIME + ", ";
                    sSQL = sSQL + "        SHINUMBER = '" + objLOGOESHP.SHINUMBER + "', ";
                    sSQL = sSQL + "        EMPLOYERCODE = '" + objLOGOESHP.EMPLOYERCODE + "', ";
                    sSQL = sSQL + "        STOREID = '" + objLOGOESHP.IDCUST + "', ";
                    sSQL = sSQL + "        IDCUST = '" + objLOGOESHP.IDCUST + "', ";
                    if (clsStartValid.IsDate(objLOGOESHP.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + objLOGOESHP.ARRIVALDATE + "', ";
                    }
                    else
                    {
                        sSQL = sSQL + "        ARRIVALDATE = '" + "" + "', ";
                    }
                    sSQL = sSQL + "        CREATEDATE = '" + objLOGOESHP.CREATEDATE + "', ";
                    sSQL = sSQL + "        SYNSTATUS = " + sStatus.Trim() + " WHERE SHIUNIQ=" + objLOGOESHP.SHIUNIQ + " ";
                    sSQL = sSQL + "    END ";
                    sSQL = sSQL + "ELSE ";
                    sSQL = sSQL + "    BEGIN";
                    if (clsStartValid.IsDate(objLOGOESHP.ARRIVALDATE))
                    {
                        sSQL = sSQL + "        INSERT INTO LOGOESHP(SHIUNIQ, AUDTDATE, AUDTTIME, SHINUMBER, EMPLOYERCODE, STOREID, IDCUST, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGOESHP.SHIUNIQ + ", " + objLOGOESHP.AUDTDATE + ", " + objLOGOESHP.AUDTTIME + ", '" + objLOGOESHP.SHINUMBER + "', '" + objLOGOESHP.EMPLOYERCODE + "','" + objLOGOESHP.IDCUST + "','" + objLOGOESHP.IDCUST + "', '" + objLOGOESHP.ARRIVALDATE + "', '" + objLOGOESHP.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    else
                    {
                        sSQL = sSQL + "        INSERT INTO LOGOESHP(SHIUNIQ, AUDTDATE, AUDTTIME, SHINUMBER, EMPLOYERCODE, STOREID, IDCUST, ARRIVALDATE, CREATEDATE, SYNSTATUS) ";
                        sSQL = sSQL + "        VALUES(" + objLOGOESHP.SHIUNIQ + ", " + objLOGOESHP.AUDTDATE + ", " + objLOGOESHP.AUDTTIME + ", '" + objLOGOESHP.SHINUMBER + "', '" + objLOGOESHP.EMPLOYERCODE + "','" + objLOGOESHP.IDCUST + "','" + objLOGOESHP.IDCUST + "', '" + "" + "', '" + objLOGOESHP.CREATEDATE + "'," + sStatus.Trim() + ")  ";
                    }
                    sSQL = sSQL + "    END";
                    DbTools.ExecuteSql(sSQL.Trim());
                }
                return true;
            }
            catch (Exception ex)
            {
                sError = ex.Message.ToString().Trim();
                return false;
            }

        }
    }
}
