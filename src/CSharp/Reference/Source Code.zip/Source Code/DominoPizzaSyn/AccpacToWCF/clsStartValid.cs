﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using CommonTools;
using System.IO;
using System.Text;
using AccpacBL;

namespace DominoPizzaSyn
{
    public static class clsStartValid
    {
        public static bool IsDate(string strDate)
        {
            try
            {
                DateTime.Parse(strDate);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool StartValid(out AccpacLogOn objAccpacLogOn, out clsDBInfo objDBIno)
        {
            #region //Var Define
            string sSetupPath = string.Empty;
            string sValue = string.Empty;
            string sNumOfRetry = string.Empty;
            string sRetrialInterval = string.Empty;
            string sError = string.Empty;
            string sInvalidString = string.Empty;
            int iNumOfRetry = 0;
            int iRetrialInterval = 0;
            LogHelper objLog = new LogHelper();
            #endregion

            objAccpacLogOn = new AccpacLogOn();
            objDBIno = new clsDBInfo();
            try
            {
                #region //Validation Setting
                sSetupPath = Path.Combine(Application.StartupPath, publicVar.STR_SETTING_FILE_NAME);
                if (!File.Exists(sSetupPath))
                {
                    sError = "Process Error Report:" + Environment.NewLine + "--" + sSetupPath.Trim() + " File is not found. " + "Please create Setup.ini file first.";
                    objLog.writeLogFile(Application.StartupPath + "\\LOG\\", DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", "", sError.Trim());
                    return false;
                }
                INIHelper objINIHelper = new INIHelper(sSetupPath);

                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_SERVER_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.ServerName = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);

                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_DATABASE_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.DBName = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_USER_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.DBUserID = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_PASSWORD_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.DBPassword = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_ACCPAC_COMPANY_ID_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.AccpacCompanyID = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_ACCPAC_USER_ID_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.AccpacUserID = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_ACCPAC_PASSWORD_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.AccpacPwd = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_APIKEY_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.APIKey = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_RETRY_COUNT_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    sNumOfRetry = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
                    objDBIno.NumOfRetry = sNumOfRetry;
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_RETRIAL_INTERVAL_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    sRetrialInterval = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);//
                    objDBIno.RetrialInterval = sRetrialInterval;
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_URL_PO_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.WebAPIUrlPO = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_URL_OE_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.WebAPIUrlOE = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_URL_IC_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.WebAPIUrlIC = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);
                }
                sValue = objINIHelper.ReadString(publicVar.STR_APPLICATION_NAME, publicVar.STR_WEB_API_USER_CAPTION);
                if (string.IsNullOrEmpty(sValue) == false)
                {
                    objDBIno.WebAPIUser = TripleDESCryptography.DESDecrypt(sValue, publicVar.S_PUBLIC_KEY, publicVar.S_PUBLIC_IV);
                }

                sInvalidString = "--Invalid Setting. ";

                if (string.IsNullOrEmpty(objDBIno.ServerName.Trim()))
                {
                    sError = sError + sInvalidString + "Server Name is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.DBName.Trim()))
                {
                    sError = sError + sInvalidString + "Database Name is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.DBUserID.Trim()))
                {
                    sError = sError + sInvalidString + "Database User ID is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.DBPassword))
                {
                    sError = sError + sInvalidString + "Database Password is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.AccpacCompanyID.Trim()))
                {
                    sError = sError + sInvalidString + "Accpac Company ID is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.AccpacUserID.Trim()))
                {
                    sError = sError + sInvalidString + "Accpac User ID is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.AccpacPwd))
                {
                    sError = sError + sInvalidString + "Accpac Password is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.APIKey.Trim()))
                {
                    sError = sError + sInvalidString + "API Key is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(sNumOfRetry.Trim()))
                {
                    sError = sError + sInvalidString + "Numbers of Retry is blank." + System.Environment.NewLine;
                }
                else
                {
                    if (int.TryParse(sNumOfRetry.Trim(), out iNumOfRetry))
                    {
                        if (iNumOfRetry != 1 && iNumOfRetry != 3 && iNumOfRetry != 5)
                        {
                            sError = sError + sInvalidString + "Numbers of Retry must be 1 or 3 or 5." + System.Environment.NewLine;
                        }
                        else
                        {
                            objDBIno.NumOfRetryInt = iNumOfRetry;
                        }
                    }
                    else
                    {
                        sError = sError + sInvalidString + "Numbers of Retry must be numeric." + System.Environment.NewLine;
                    }
                }
                if (string.IsNullOrEmpty(sRetrialInterval.Trim()))
                {
                    sError = sError + sInvalidString + "Retrial Interval is blank." + System.Environment.NewLine;
                }
                else
                {
                    if (int.TryParse(sRetrialInterval.Trim(), out iRetrialInterval))
                    {
                        if (iRetrialInterval < 0)
                        {
                            sError = sError + sInvalidString + "Retrial Interval must be greater than 0." + System.Environment.NewLine;
                        }
                        else
                        {
                            objDBIno.RetrialIntervalInt = iRetrialInterval;
                        }
                    }
                    else
                    {
                        sError = sError + sInvalidString + "Retrial Interval must be numeric." + System.Environment.NewLine;
                    }
                }
                if (string.IsNullOrEmpty(objDBIno.WebAPIUrlPO.Trim()))
                {
                    sError = sError + sInvalidString + "PO Web API Url is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.WebAPIUrlOE.Trim()))
                {
                    sError = sError + sInvalidString + "OE Web API Url is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.WebAPIUrlIC.Trim()))
                {
                    sError = sError + sInvalidString + "IC Web API Url is blank." + System.Environment.NewLine;
                }
                if (string.IsNullOrEmpty(objDBIno.WebAPIUser.Trim()))
                {
                    sError = sError + sInvalidString + "Web API User is blank." + System.Environment.NewLine;
                }
                #endregion

                #region //Validation Connection
                if (string.IsNullOrEmpty(sError.Trim()))
                {
                    objAccpacLogOn.CurrVersion = publicVar.STR_ACCPAC_VERSION;
                    objAccpacLogOn.CompanyID = objDBIno.AccpacCompanyID.Trim();
                    objAccpacLogOn.UserID = objDBIno.AccpacUserID.Trim();
                    objAccpacLogOn.Pwd = objDBIno.AccpacPwd;
                    objAccpacLogOn.dtSessionDate = DateTime.Now;
                    if (objAccpacLogOn.OpenSessionDBLink(out sError) == false)
                    {
                        sError = "Process Error Report:" + Environment.NewLine + "--" + sError.Trim();
                        objLog.writeLogFile(Application.StartupPath + "\\LOG\\", DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", "", sError.Trim());
                        return false;
                    }

                    string connectionString = "Server=" + objDBIno.ServerName.Trim() + ";database=" + objDBIno.DBName.Trim() + ";uid=" + objDBIno.DBUserID.Trim() + ";pwd=" + objDBIno.DBPassword;
                    DbTools.ConnectionString = connectionString;
                    if (DbTools.CheckConnection() == false)
                    {
                        sError = "Process Error Report:" + Environment.NewLine + "--" + DbTools.ErrorMessage.Trim();
                        objLog.writeLogFile(Application.StartupPath + "\\LOG\\", DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", "", sError.Trim());
                        return false;
                    }
                }
                else
                {
                    sError = "Process Error Report:" + Environment.NewLine + sError.Trim();
                    objLog.writeLogFile(Application.StartupPath + "\\LOG\\", DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", "", sError.Trim());
                    return false;
                }
                #endregion

                return true;
            }
            catch (Exception ex)
            {
                sError = "Process Error Report:" + Environment.NewLine + "Start Validation Error. " + ex.Message.ToString().Trim();
                objLog.writeLogFile(Application.StartupPath + "\\LOG\\", DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", "", sError.Trim());
                return false;
            }
        }
    }
}
