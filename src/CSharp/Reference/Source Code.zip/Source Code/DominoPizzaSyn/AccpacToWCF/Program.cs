﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using CommonTools;
using System.IO;
using System.Text;
using AccpacBL;

namespace DominoPizzaSyn
{
    static class Program
    {
        private static System.Threading.Mutex mutex;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            AccpacLogOn objAccpacLogOn = new AccpacLogOn();
            clsDBInfo objDBIno = new clsDBInfo();

            #region //Valid program running
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            mutex = new System.Threading.Mutex(true, "DominoPizzaSyn");
            if (mutex.WaitOne(0, false))
            {
            }
            else
            {
                Application.Exit();
                return;
            }
            #endregion

            if (clsStartValid.StartValid(out objAccpacLogOn, out objDBIno))
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmMain(objDBIno, objAccpacLogOn));
            }
        }
    }
}
