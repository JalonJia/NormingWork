﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using CommonTools;
using AccpacBL;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace DominoPizzaSyn
{
    public partial class frmMain : Form
    {
        public AccpacLogOn _AccpacLogOn;
        clsDBInfo _objDBIno = new clsDBInfo();
        private int _iRetryCount = 0;
        private bool _bPOOrder = false;
        private bool _bOEShip = false;
        private bool _bICInt = false;
        private LogHelper _objLog = new LogHelper();
        private string _sDatetime = string.Empty;
        private bool _bMainProcess = false;

        public frmMain(clsDBInfo objDBIno, AccpacLogOn objAccpacLogOn)
        {
            InitializeComponent();

            _objDBIno = objDBIno;
            _AccpacLogOn = objAccpacLogOn;

            _iRetryCount = 0;

            _objLog = new LogHelper();
        }
        
        #region //Hide Program to Task Bar***********************************************************************************************************************
        private void frmMain_Load(object sender, EventArgs e)
        {
            string sResult = string.Empty;

            try
            {
                this.Text = _AccpacLogOn.CompanyID + " - " + this.Text.Trim();

                string startup = Application.ExecutablePath;
                int pp = startup.LastIndexOf("\\");
                startup = startup.Substring(0, pp);

                hideMenuItem.Visible = false;
                this.WindowState = FormWindowState.Minimized;
                this.Hide();

                Console.WriteLine(tmrProcess.Interval.ToString());

                tmrProcess.Interval = publicVar.I_MS * publicVar.I_SECOND * _objDBIno.RetrialIntervalInt;

                _bPOOrder = false;
                _bOEShip = false;
                _bICInt = false;

                MainProcess();
            }
            catch (Exception ex)
            {
                sResult = "Process Error Report:" + Environment.NewLine + "--frmMain_Load Error:" + Environment.NewLine  + "----" + ex.Message.ToString().Trim();
                if (!string.IsNullOrEmpty(sResult.Trim()))
                {
                    _objLog.writeLogFile(Application.StartupPath + "\\LOG\\", DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", "", sResult.Trim());
                }
            }
            
        }

        private void frmMain_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Hide(); //Or - this.Visible = false;
                this.niconTask.Visible = true;
            }
        }

        private void exitMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to quit?", this.Text.Trim(), MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                if (tmrProcess.Enabled)
                {
                    tmrProcess.Stop();
                }
                tmrProcess.Enabled = false;

                niconTask.Visible = false;
                this.Close();
                this.Dispose();
                Application.Exit();
            }
        }

        private void hideMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void showMenuItem_Click(object sender, EventArgs e)
        {
            this.Show();
            this.WindowState = FormWindowState.Normal;
            this.Activate();
            Application.DoEvents();
        }

        private void niconTask_DoubleClick(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Minimized;
                this.Hide();
            }
            else if (this.WindowState == FormWindowState.Minimized)
            {
                this.Show();
                this.WindowState = FormWindowState.Normal;
                this.Activate();
            }
            Application.DoEvents();
        }
        #endregion /**********************************************************************************************************************************************

        private void ControlEnabled(bool bEnabled)
        {
            if (bEnabled)
            {
                lbl_Process.Text = "Ready";
                Application.DoEvents();
                //lbl_Process.Visible = false;
            }
            else
            {
                lbl_Process.Text = "Processing...";
                Application.DoEvents();
                //lbl_Process.Visible = true;
            }
            Application.DoEvents();
            btnClose.Enabled = bEnabled;
        }

        private void MainProcess()
        {
            string sResult = string.Empty;
            string sError = string.Empty;
            string sPOOrdResult = string.Empty;
            string sOEShpResult = string.Empty;
            string sICIntResult = string.Empty;
            string sPOOrdError = string.Empty;
            string sOEShpError = string.Empty;
            string sICIntError = string.Empty;

            ControlEnabled(false);
            try
            {
                if (_bMainProcess == false)
                {
                    _sDatetime = DateTime.Now.ToString("yyyyMMddHHmmss");
                    _bMainProcess = true;
                }
                if (_bPOOrder == false)
                {
                    this.lbl_Process.Text = "Processing PO Order...";
                    Application.DoEvents();
                    _bPOOrder = ProcessPO(out sPOOrdResult, out sPOOrdError);
                }
                if (_bOEShip == false)
                {
                    this.lbl_Process.Text = "Processing OE Shipment...";
                    Application.DoEvents();
                    _bOEShip = ProcessOE(out sOEShpResult, out sOEShpError);
                }
                if (_bICInt == false)
                {
                    this.lbl_Process.Text = "Processing IC Internal Usage...";
                    Application.DoEvents();
                    _bICInt = ProcessIC(out sICIntResult, out sICIntError);
                }

                sError = string.Empty;
                sResult = string.Empty;
                if (!string.IsNullOrEmpty(sPOOrdResult.Trim()))
                {
                    sResult = sResult + sPOOrdResult.Trim() + Environment.NewLine + Environment.NewLine;
                }
                if (!string.IsNullOrEmpty(sOEShpResult.Trim()))
                {
                    sResult = sResult + sOEShpResult.Trim() + Environment.NewLine + Environment.NewLine;
                }
                if (!string.IsNullOrEmpty(sICIntResult.Trim()))
                {
                    sResult = sResult + sICIntResult.Trim() + Environment.NewLine + Environment.NewLine;
                }

                if (!string.IsNullOrEmpty(sPOOrdError.Trim()))
                {
                    sError = sError + sPOOrdError.Trim() + Environment.NewLine + Environment.NewLine;
                }
                if (!string.IsNullOrEmpty(sOEShpError.Trim()))
                {
                    sError = sError + sOEShpError.Trim() + Environment.NewLine + Environment.NewLine;
                }
                if (!string.IsNullOrEmpty(sICIntError.Trim()))
                {
                    sError = sError + sICIntError.Trim() + Environment.NewLine + Environment.NewLine;
                }
            }
            catch (Exception ex)
            {
                if (string.IsNullOrEmpty(sError))
                {
                    sError = "--Syn Error:" + Environment.NewLine + "----" + ex.Message.ToString().Trim();
                }
                else
                {
                    sError = "--Syn Error:" + Environment.NewLine + "----" + ex.Message.ToString().Trim() + Environment.NewLine + sError;
                }
            }
            finally
            {
                if (!string.IsNullOrEmpty(sResult.Trim()))
                {
                    sResult = "Process Result Report:" + Environment.NewLine + sResult + Environment.NewLine;
                }
                if (!string.IsNullOrEmpty(sError.Trim()))
                {
                    sResult = sResult + Environment.NewLine + "Process Error Report:" + Environment.NewLine + sError;
                }
                if (!string.IsNullOrEmpty(sResult.Trim()))
                {
                    _objLog.writeLogFile(Application.StartupPath + "\\LOG\\", DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", "", sResult.Trim());
                }

                //Console.WriteLine(tmrProcess.Interval.ToString());

                ControlEnabled(true);

                if (_bPOOrder == false || _bOEShip == false || _bICInt == false)
                {
                    //tmrProcess.Interval = publicVar.I_MS * publicVar.I_SECOND * _objDBIno.RetrialIntervalInt;
                    tmrProcess.Enabled = true;
                    tmrProcess.Start();
                }
                else
                {
                    tmrProcess.Enabled = false;
                    tmrProcess.Stop();

                    this.Close();

                    this.Dispose();
                    Application.Exit();
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to quit?", this.Text.Trim(), MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                if (tmrProcess.Enabled)
                {
                    tmrProcess.Stop();
                }
                tmrProcess.Enabled = false;

                this.Close();

                this.Dispose();
                Application.Exit();
            }
        }

        private void tmrProcess_Tick(object sender, EventArgs e)
        {
            string sResult = string.Empty;

            try
            {
                _iRetryCount = _iRetryCount + 1;

                Console.WriteLine(DateTime.Now.ToString());

                MainProcess();
            }
            catch (Exception ex)
            {
                sResult = "Process Error Report:" + Environment.NewLine + "--tmrProcess_Tick Error:" + Environment.NewLine + "----" + ex.Message.ToString().Trim();
                if (!string.IsNullOrEmpty(sResult.Trim()))
                {
                    _objLog.writeLogFile(Application.StartupPath + "\\LOG\\", DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", "", sResult.Trim());
                }
            }
            finally
            {
                if (_iRetryCount >= _objDBIno.NumOfRetryInt)
                {
                    tmrProcess.Stop();
                    tmrProcess.Enabled = false;

                    this.Close();

                    this.Dispose();
                    Application.Exit();
                }
            }
        }

        private bool ProcessPO(out string sResult, out string sError)
        {
            string sPOOrdData = string.Empty;
            int iPOOrdRecordCount = 0;
            bool bWCFSuccess = false;
            List<clsLOGPOORD> lstRecord = new List<clsLOGPOORD>();
            string sRetMsg = string.Empty;
            string sRetCode = string.Empty;
            string sRetData = string.Empty;
            string sSign = string.Empty;
            string sUrl = string.Empty;
            MD5Helper objMD5 = new MD5Helper();
            string sDateTime = string.Empty;
            Dictionary<string, string> dicSucceed = new Dictionary<string, string>();
            Dictionary<string, string> dicFailed = new Dictionary<string, string>();

            sResult = string.Empty;
            sError = string.Empty;

            try
            {
                sPOOrdData = string.Empty;
                sError = string.Empty;
                lbl_Process.Text = "Reading PO Order Data...";
                Application.DoEvents();
                clsProcessPO.ReadPOOrder(DbTools.ConnectionString, _objDBIno.AccpacCompanyID, out lstRecord, out sPOOrdData, out sError);
                iPOOrdRecordCount = lstRecord.Count;

                if (string.IsNullOrEmpty(sPOOrdData.Trim()))
                {
                    sResult = "--PO order syn Result:" + Environment.NewLine + "----No matched PO Order record to process.";
                    return true;
                }
                else
                {
                    
                    if (!string.IsNullOrEmpty(sPOOrdData.Trim()))
                    {
                        _objLog.writeLogFile(Application.StartupPath + "\\JsonData\\", "PO_" + _sDatetime.Trim() + ".txt", "", sPOOrdData.Trim(), true);
                    }

                    if (string.IsNullOrEmpty(sError.Trim()))
                    {
                        //Add WCF Function*****************************
                        lbl_Process.Text = "Sending PO Order Data...";
                        Application.DoEvents();

                        sDateTime = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                        sSign = _objDBIno.APIKey.Trim() + "username=" + _objDBIno.WebAPIUser.Trim() + "timestamp=" + sDateTime.Trim();
                        sSign = objMD5.MakeSign(sSign);
                        sUrl = _objDBIno.WebAPIUrlPO +  @"?username=" + _objDBIno.WebAPIUser.Trim() +
                               "&timestamp=" + sDateTime.Trim() +
                               "&sign=" + sSign;
                        bWCFSuccess = clsWebAPIProcess.HttpPost(sUrl.Trim(), sPOOrdData, out sRetCode, out sRetMsg, out sRetData, out dicSucceed, out dicFailed);

                        lbl_Process.Text = "Processing PO Order Data Result...";
                        Application.DoEvents();
                        //********************************************
                        if (bWCFSuccess)
                        {
                            clsProcessPO.SynLOGPOOrder(DbTools.ConnectionString, lstRecord, dicSucceed, out sError);

                            if (iPOOrdRecordCount>1)
                            {
                                sResult = "--PO order syn Result: --" + iPOOrdRecordCount.ToString().Trim() + " PO orders syn Succeed.";
                            }
                            else
                            {
                                sResult = "--PO order syn Result: --" + iPOOrdRecordCount.ToString().Trim() + " PO order syn Succeed.";
                            }

                            if (dicSucceed.Count > 0)
                            {
                                foreach (KeyValuePair<string, string> objSucceed in dicSucceed)
                                {
                                    Application.DoEvents();
                                    sResult = sResult + Environment.NewLine + "----Syn Succeed PO Order # " + objSucceed.Value.ToString().Trim() + ".";
                                }
                            }
                            return true;
                        }
                        else
                        {
                            if (dicSucceed.Count > 0)
                            {
                                if (dicSucceed.Count > 1)
                                {
                                    sResult = "--PO order syn Result: --" + dicSucceed.Count.ToString().Trim() + " PO orders syn Succeed.";
                                }
                                else
                                {
                                    sResult = "--PO order syn Result: --" + dicSucceed.Count.ToString().Trim() + " PO order syn Succeed.";
                                }
                                foreach (KeyValuePair<string, string> objSucceed in dicSucceed)
                                {
                                    Application.DoEvents();
                                    if (dicFailed.ContainsKey(objSucceed.Value.ToString().Trim()) == false)
                                    {
                                        sResult = sResult + Environment.NewLine + "----Syn Succeed PO Order # " + objSucceed.Value.ToString().Trim() + ".";
                                    }
                                }
                            }

                            lbl_Process.Text = "Updating PO Order Data Status...";
                            Application.DoEvents();

                            clsProcessPO.SynLOGPOOrder(DbTools.ConnectionString, lstRecord, dicSucceed, out sError);
                            if (string.IsNullOrEmpty(sError) || string.IsNullOrEmpty(sRetMsg))
                            {
                                sError = "--PO order syn Failed:" + Environment.NewLine + "----" + sRetMsg;
                            }
                            else
                            {
                                sError = "--PO order syn Failed:" + Environment.NewLine + "----" + sRetMsg + Environment.NewLine + "----" + sError;
                            }

                            if (dicFailed.Count > 0)
                            {
                                foreach (KeyValuePair<string, string> objFailed in dicFailed)
                                {
                                    Application.DoEvents();
                                    sError = sError + Environment.NewLine + "----Syn Failed PO Order # " + objFailed.Value.ToString().Trim() + ".";
                                }
                            }
                            return false;
                        }
                    }
                    else
                    {
                        lbl_Process.Text = "Updating PO Order Data Status...";
                        Application.DoEvents();

                        clsProcessPO.SynLOGPOOrder(DbTools.ConnectionString, publicVar.S_STATUS_NON_SYN, lstRecord, out sError);
      
                        sError = "--PO order syn Failed:" + Environment.NewLine + "----" + sError;

                        foreach (clsLOGPOORD objLOGPOORD in lstRecord)
                        {
                            Application.DoEvents();
                            sError = sError + Environment.NewLine + "----Syn Failed PO Order # " + objLOGPOORD.PONUMBER.ToString().Trim() + ".";
                        }
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                if (string.IsNullOrEmpty(sError))
                {
                    sError = "--PO order syn Error:" + Environment.NewLine + "----" + ex.Message.ToString().Trim();
                }
                else
                {
                    sError=  "--PO order syn Error:" + Environment.NewLine + "----" + ex.Message.ToString().Trim() + Environment.NewLine + sError ;
                }
                return false;
            }
        }

        private bool ProcessOE(out string sResult, out string sError)
        {
            string sOEShpData = string.Empty;
            int iOEShpRecordCount = 0;
            bool bWCFSuccess = false;
            List<clsLOGOESHIP> lstRecord = new List<clsLOGOESHIP>();
            string sRetMsg = string.Empty;
            string sRetCode = string.Empty;
            string sRetData = string.Empty;
            string sSign = string.Empty;
            string sUrl = string.Empty;
            MD5Helper objMD5 = new MD5Helper();
            string sDateTime = string.Empty;
            Dictionary<string, string> dicSucceed = new Dictionary<string, string>();
            Dictionary<string, string> dicFailed = new Dictionary<string, string>();

            sResult = string.Empty;
            sError = string.Empty;

            try
            {
                sOEShpData = string.Empty;
                sError = string.Empty;
                lbl_Process.Text = "Reading OE Shipment Data...";
                Application.DoEvents();
                clsProcessOE.ReadOEShip(DbTools.ConnectionString, _objDBIno.AccpacCompanyID, out lstRecord, out sOEShpData, out sError);
                iOEShpRecordCount = lstRecord.Count;

                if (string.IsNullOrEmpty(sOEShpData.Trim()))
                {
                    sResult = "--OE Shipment syn Result:" + Environment.NewLine + "----No matched OE Shipment record to process.";
                    return true;
                }
                else
                {
                    if (!string.IsNullOrEmpty(sOEShpData.Trim()))
                    {
                        _objLog.writeLogFile(Application.StartupPath + "\\JsonData\\", "OE_" + _sDatetime.Trim() + ".txt", "", sOEShpData.Trim(), true);
                    }

                    if (string.IsNullOrEmpty(sError.Trim()))
                    {
                        //Add WCF Function*****************************
                        lbl_Process.Text = "Sending OE Shipment Data...";
                        Application.DoEvents();

                        sDateTime = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                        sSign = _objDBIno.APIKey.Trim() + "username=" + _objDBIno.WebAPIUser.Trim() + "timestamp=" + sDateTime.Trim();
                        sSign = objMD5.MakeSign(sSign);
                        sUrl = _objDBIno.WebAPIUrlOE + @"?username=" + _objDBIno.WebAPIUser.Trim() +
                               "&timestamp=" + sDateTime.Trim() +
                               "&sign=" + sSign;
                        bWCFSuccess = clsWebAPIProcess.HttpPost(sUrl.Trim(), sOEShpData, out sRetCode, out sRetMsg, out sRetData, out dicSucceed, out dicFailed);

                        lbl_Process.Text = "Processing OE Shipment Result...";
                        Application.DoEvents();
                        //********************************************
                        if (bWCFSuccess)
                        {
                            clsProcessOE.SynLOGOEShip(DbTools.ConnectionString, publicVar.S_STATUS_SUCCEED_SYN, lstRecord, out sError);

                            if (iOEShpRecordCount > 1)
                            {
                                sResult = "--OE Shipment syn Result: --" + iOEShpRecordCount.ToString().Trim() + " OE Shipments syn Succeed.";
                            }
                            else
                            {
                                sResult = "--OE Shipment syn Result: --" + iOEShpRecordCount.ToString().Trim() + " OE Shipment syn Succeed.";
                            }

                            if (dicSucceed.Count > 0)
                            {
                                foreach (KeyValuePair<string, string> objSucceed in dicSucceed)
                                {
                                    Application.DoEvents();
                                    sResult = sResult + Environment.NewLine + "----Syn Succeed OE Shipment # " + objSucceed.Value.ToString().Trim() + ".";
                                }
                            }
                            return true;
                        }
                        else
                        {
                            if (dicSucceed.Count > 0)
                            {
                                if (dicSucceed.Count > 1)
                                {
                                    sResult = "--OE Shipment syn Result: --" + dicSucceed.Count.ToString().Trim() + " OE Shipments syn Succeed.";
                                }
                                else
                                {
                                    sResult = "--OE Shipment syn Result: --" + dicSucceed.Count.ToString().Trim() + " OE Shipment syn Succeed.";
                                }
                                foreach (KeyValuePair<string, string> objSucceed in dicSucceed)
                                {
                                    Application.DoEvents();
                                    if (dicFailed.ContainsKey(objSucceed.Value.ToString().Trim()) == false)
                                    {
                                        sResult = sResult + Environment.NewLine + "----Syn Succeed OE Shipment # " + objSucceed.Value.ToString().Trim() + ".";
                                    }
                                }
                            }

                            lbl_Process.Text = "Updating OE Shipment Data Status...";
                            Application.DoEvents();

                            clsProcessOE.SynLOGOEShip(DbTools.ConnectionString, publicVar.S_STATUS_NON_SYN, lstRecord, out sError);
                            if (string.IsNullOrEmpty(sError) || string.IsNullOrEmpty(sRetMsg))
                            {
                                sError = "--OE Shipment syn Failed:" + Environment.NewLine + "----" + sRetMsg;
                            }
                            else
                            {
                                sError = "--OE Shipment syn Failed:" + Environment.NewLine + "----" + sRetMsg + Environment.NewLine + "----" + sError;
                            }

                            if (dicFailed.Count > 0)
                            {
                                foreach (KeyValuePair<string, string> objFailed in dicFailed)
                                {
                                    Application.DoEvents();
                                    sError = sError + Environment.NewLine + "----Syn Failed OE Shipment # " + objFailed.Value.ToString().Trim() + ".";
                                }
                            }
                            return false;
                        }
                    }
                    else
                    {
                        lbl_Process.Text = "Updating OE Shipment Data Status...";
                        Application.DoEvents();

                        clsProcessOE.SynLOGOEShip(DbTools.ConnectionString, publicVar.S_STATUS_NON_SYN, lstRecord, out sError);

                        sError = "--OE Shipment syn Failed:" + Environment.NewLine + "----" + sError;

                        foreach (clsLOGOESHIP objLOGOESHIP in lstRecord)
                        {
                            Application.DoEvents();
                            sError = sError + Environment.NewLine + "----Syn Failed OE Shipment # " + objLOGOESHIP.SHINUMBER.ToString().Trim() + ".";
                        }
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                if (string.IsNullOrEmpty(sError))
                {
                    sError = "--OE Shipment syn Error:" + Environment.NewLine + "----" + ex.Message.ToString().Trim();
                }
                else
                {
                    sError = "--OE Shipment syn Error:" + Environment.NewLine + "----" + ex.Message.ToString().Trim() + Environment.NewLine + sError;
                }
                return false;
            }
        }

        private bool ProcessIC(out string sResult, out string sError)
        {
            string sICIntData = string.Empty;
            int iICIntRecordCount = 0;
            bool bWCFSuccess = false;
            List<clsLOGOICINT> lstRecord = new List<clsLOGOICINT>();
            string sRetMsg = string.Empty;
            string sRetCode = string.Empty;
            string sRetData = string.Empty;
            string sSign = string.Empty;
            string sUrl = string.Empty;
            MD5Helper objMD5 = new MD5Helper();
            string sDateTime = string.Empty;
            Dictionary<string, string> dicSucceed = new Dictionary<string, string>();
            Dictionary<string, string> dicFailed = new Dictionary<string, string>();

            sResult = string.Empty;
            sError = string.Empty;

            try
            {
                sICIntData = string.Empty;
                sError = string.Empty;
                lbl_Process.Text = "Reading IC Internal Usage Data...";
                Application.DoEvents();
                clsProcessIC.ReadICInt(DbTools.ConnectionString, _objDBIno.AccpacCompanyID, out lstRecord, out sICIntData, out sError);
                iICIntRecordCount = lstRecord.Count;

                if (string.IsNullOrEmpty(sICIntData.Trim()))
                {
                    sResult = "--IC Internal Usage syn Result:" + Environment.NewLine + "----No matched IC Internal Usage record to process.";
                    return true;
                }
                else
                {
                    if (!string.IsNullOrEmpty(sICIntData.Trim()))
                    {
                        _objLog.writeLogFile(Application.StartupPath + "\\JsonData\\", "IC_" + _sDatetime.Trim() + ".txt", "", sICIntData.Trim(), true);
                    }

                    if (string.IsNullOrEmpty(sError.Trim()))
                    {
                        //Add WCF Function*****************************
                        lbl_Process.Text = "Sending IC Internal Usage Data...";
                        Application.DoEvents();

                        sDateTime = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                        sSign = _objDBIno.APIKey.Trim() + "username=" + _objDBIno.WebAPIUser.Trim() + "timestamp=" + sDateTime.Trim();
                        sSign = objMD5.MakeSign(sSign);
                        sUrl = _objDBIno.WebAPIUrlIC + @"?username=" + _objDBIno.WebAPIUser.Trim() +
                               "&timestamp=" + sDateTime.Trim() +
                               "&sign=" + sSign;
                        bWCFSuccess = clsWebAPIProcess.HttpPost(sUrl.Trim(), sICIntData, out sRetCode, out sRetMsg, out sRetData, out dicSucceed, out dicFailed);

                        lbl_Process.Text = "Processing IC Internal Usage Result...";
                        Application.DoEvents();
                        //********************************************
                        if (bWCFSuccess)
                        {
                            clsProcessIC.SynLOGICInt(DbTools.ConnectionString, publicVar.S_STATUS_SUCCEED_SYN, lstRecord, out sError);

                            if (iICIntRecordCount > 1)
                            {
                                sResult = "--IC Internal Usage syn Result: --" + iICIntRecordCount.ToString().Trim() + " IC Internal Usage syn Succeed.";
                            }
                            else
                            {
                                sResult = "--IC Internal Usage syn Result: --" + iICIntRecordCount.ToString().Trim() + " IC Internal Usage syn Succeed.";
                            }

                            if (dicSucceed.Count > 0)
                            {
                                foreach (KeyValuePair<string, string> objSucceed in dicSucceed)
                                {
                                    Application.DoEvents();
                                    sResult = sResult + Environment.NewLine + "----Syn Succeed IC Internal Usage # " + objSucceed.Value.ToString().Trim() + ".";
                                }
                            }
                            return true;
                        }
                        else
                        {
                            if (dicSucceed.Count > 0)
                            {
                                if (dicSucceed.Count > 1)
                                {
                                    sResult = "--IC Internal Usage syn Result: --" + dicSucceed.Count.ToString().Trim() + " IC Internal Usage syn Succeed.";
                                }
                                else
                                {
                                    sResult = "--IC Internal Usage syn Result: --" + dicSucceed.Count.ToString().Trim() + " IC Internal Usage syn Succeed.";
                                }
                                foreach (KeyValuePair<string, string> objSucceed in dicSucceed)
                                {
                                    Application.DoEvents();
                                    if (dicFailed.ContainsKey(objSucceed.Value.ToString().Trim()) == false)
                                    {
                                        sResult = sResult + Environment.NewLine + "----Syn Succeed IC Internal Usage # " + objSucceed.Value.ToString().Trim() + ".";
                                    }
                                }
                            }

                            lbl_Process.Text = "Updating IC Internal Usage Status...";
                            Application.DoEvents();

                            clsProcessIC.SynLOGICInt(DbTools.ConnectionString, publicVar.S_STATUS_NON_SYN, lstRecord, out sError);
                            if (string.IsNullOrEmpty(sError) || string.IsNullOrEmpty(sRetMsg))
                            {
                                sError = "--IC Internal Usage syn Failed:" + Environment.NewLine + "----" + sRetMsg;
                            }
                            else
                            {
                                sError = "--IC Internal Usage syn Failed:" + Environment.NewLine + "----" + sRetMsg + Environment.NewLine + "----" + sError;
                            }

                            if (dicFailed.Count > 0)
                            {
                                foreach (KeyValuePair<string, string> objFailed in dicFailed)
                                {
                                    Application.DoEvents();
                                    sError = sError + Environment.NewLine + "----Syn Failed IC Internal Usage # " + objFailed.Value.ToString().Trim() + ".";
                                }
                            }
                            return false;
                        }
                    }
                    else
                    {
                        lbl_Process.Text = "Updating IC Internal Usage Status...";
                        Application.DoEvents();

                        clsProcessIC.SynLOGICInt(DbTools.ConnectionString, publicVar.S_STATUS_NON_SYN, lstRecord, out sError);

                        sError = "--IC Internal Usage syn Failed:" + Environment.NewLine + "----" + sError;

                        foreach (clsLOGOICINT objLOGOICINT in lstRecord)
                        {
                            Application.DoEvents();
                            sError = sError + Environment.NewLine + "----Syn Failed IC Internal Usage # " + objLOGOICINT.DOCNUM.ToString().Trim() + ".";
                        }
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                if (string.IsNullOrEmpty(sError))
                {
                    sError = "--IC Internal Usage syn Error:" + Environment.NewLine + "----" + ex.Message.ToString().Trim();
                }
                else
                {
                    sError = "--IC Internal Usage syn Error:" + Environment.NewLine + "----" + ex.Message.ToString().Trim() + Environment.NewLine + sError;
                }
                return false;
            }
        }

        
    }
}
