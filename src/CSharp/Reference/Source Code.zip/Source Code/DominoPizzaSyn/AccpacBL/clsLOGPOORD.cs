﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

namespace AccpacBL
{
    public class clsLOGPOORD
    {
        private string sPORHSEQ = string.Empty;
        private string sAUDTDATE = string.Empty;
        private string sAUDTTIME = string.Empty;
        private string sPONUMBER = string.Empty;
        private string sEMPLOYERCODE = string.Empty;
        private string sVDCODE = string.Empty;
        private string sARRIVALDATE = string.Empty;
        private string sCREATEDATE = string.Empty;
        private string sSYNSTATUS = string.Empty;

        public string PORHSEQ
        {
            get
            {
                return sPORHSEQ;
            }

            set
            {
                sPORHSEQ = value;
            }
        }

        public string AUDTDATE
        {
            get
            {
                return sAUDTDATE;
            }

            set
            {
                sAUDTDATE = value;
            }
        }

        public string AUDTTIME
        {
            get
            {
                return sAUDTTIME;
            }

            set
            {
                sAUDTTIME = value;
            }
        }

        public string PONUMBER
        {
            get
            {
                return sPONUMBER;
            }

            set
            {
                sPONUMBER = value;
            }
        }

        public string EMPLOYERCODE
        {
            get
            {
                return sEMPLOYERCODE;
            }

            set
            {
                sEMPLOYERCODE = value;
            }
        }

        public string VDCODE
        {
            get
            {
                return sVDCODE;
            }

            set
            {
                sVDCODE = value;
            }
        }

        public string ARRIVALDATE
        {
            get
            {
                return sARRIVALDATE;
            }

            set
            {
                sARRIVALDATE = value;
            }
        }

        public string CREATEDATE
        {
            get
            {
                return sCREATEDATE;
            }

            set
            {
                sCREATEDATE = value;
            }
        }

        public string SYNSTATUS
        {
            get
            {
                return sSYNSTATUS;
            }

            set
            {
                sSYNSTATUS = value;
            }
        }
    }
}
