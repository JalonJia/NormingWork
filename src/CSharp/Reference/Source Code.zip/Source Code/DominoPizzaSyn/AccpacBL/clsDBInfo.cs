﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

namespace AccpacBL
{
    public class clsDBInfo
    {
        private string sServer = string.Empty;
        private string sDBName = string.Empty;
        private string sDBUserID = string.Empty;
        private string sDBPassword = string.Empty;
        private string sAccpacCompanyID = string.Empty;
        private string sAccpacUserID = string.Empty;
        private string sAccpacPwd = string.Empty;
        private string sAPIKey = string.Empty;
        private string sNumOfRetry = string.Empty;
        private int iNumOfRetry = 0;
        private string sRetrialInterval = string.Empty;
        private int iRetrialInterval = 0;
        private string sWebAPIUrlPO = string.Empty;
        private string sWebAPIUrlOE = string.Empty;
        private string sWebAPIUrlIC = string.Empty;
        private string sWebAPIUser = string.Empty;

        public string ServerName
        {
            get { return sServer; }
            set { sServer = value; }
        }

        public string DBName
        {
            get { return sDBName; }
            set { sDBName = value; }
        }

        public string DBUserID
        {
            get { return sDBUserID; }
            set { sDBUserID = value; }
        }
        
        public string DBPassword
        {
            get { return sDBPassword; }
            set { sDBPassword = value; }
        }

        public string AccpacCompanyID
        {
            get { return sAccpacCompanyID; }
            set { sAccpacCompanyID = value; }
        }

        public string AccpacUserID
        {
            get { return sAccpacUserID; }
            set { sAccpacUserID = value; }
        }

        public string AccpacPwd
        {
            get { return sAccpacPwd; }
            set { sAccpacPwd = value; }
        }

        public string APIKey
        {
            get { return sAPIKey; }
            set { sAPIKey = value; }
        }

        public string NumOfRetry
        {
            get { return sNumOfRetry; }
            set { sNumOfRetry = value; }
        }

        public int NumOfRetryInt
        {
            get { return iNumOfRetry; }
            set { iNumOfRetry = value; }
        }

        public string RetrialInterval
        {
            get
            {
                return sRetrialInterval;
            }

            set
            {
                sRetrialInterval = value;
            }
        }

        public int RetrialIntervalInt
        {
            get
            {
                return iRetrialInterval;
            }

            set
            {
                iRetrialInterval = value;
            }
        }

        public string WebAPIUrlPO
        {
            get
            {
                return sWebAPIUrlPO;
            }

            set
            {
                sWebAPIUrlPO = value;
            }
        }

        public string WebAPIUrlOE
        {
            get
            {
                return sWebAPIUrlOE;
            }

            set
            {
                sWebAPIUrlOE = value;
            }
        }

        public string WebAPIUrlIC
        {
            get
            {
                return sWebAPIUrlIC;
            }

            set
            {
                sWebAPIUrlIC = value;
            }
        }

        public string WebAPIUser
        {
            get
            {
                return sWebAPIUser;
            }

            set
            {
                sWebAPIUser = value;
            }
        }
    }
}
