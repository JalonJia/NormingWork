﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

namespace AccpacBL
{
    public class clsLOGOESHIP
    { 
        private string sSHIUNIQ = string.Empty;
        private string sAUDTDATE = string.Empty;
        private string sAUDTTIME = string.Empty;
        private string sSHINUMBER = string.Empty;
        private string sEMPLOYERCODE = string.Empty;
        private string sSTOREID = string.Empty;
        private string sIDCUST = string.Empty;
        private string sARRIVALDATE = string.Empty;
        private string sCREATEDATE = string.Empty;
        private string sSYNSTATUS = string.Empty;

        public string SHIUNIQ
        {
            get
            {
                return sSHIUNIQ;
            }

            set
            {
                sSHIUNIQ = value;
            }
        }

        public string AUDTDATE
        {
            get
            {
                return sAUDTDATE;
            }

            set
            {
                sAUDTDATE = value;
            }
        }

        public string AUDTTIME
        {
            get
            {
                return sAUDTTIME;
            }

            set
            {
                sAUDTTIME = value;
            }
        }

        public string SHINUMBER
        {
            get
            {
                return sSHINUMBER;
            }

            set
            {
                sSHINUMBER = value;
            }
        }

        public string EMPLOYERCODE
        {
            get
            {
                return sEMPLOYERCODE;
            }

            set
            {
                sEMPLOYERCODE = value;
            }
        }

        public string STOREID
        {
            get
            {
                return sSTOREID;
            }

            set
            {
                sSTOREID = value;
            }
        }

        public string IDCUST
        {
            get
            {
                return sIDCUST;
            }

            set
            {
                sIDCUST = value;
            }
        }

        public string ARRIVALDATE
        {
            get
            {
                return sARRIVALDATE;
            }

            set
            {
                sARRIVALDATE = value;
            }
        }

        public string CREATEDATE
        {
            get
            {
                return sCREATEDATE;
            }

            set
            {
                sCREATEDATE = value;
            }
        }

        public string SYNSTATUS
        {
            get
            {
                return sSYNSTATUS;
            }

            set
            {
                sSYNSTATUS = value;
            }
        }

    }
}
