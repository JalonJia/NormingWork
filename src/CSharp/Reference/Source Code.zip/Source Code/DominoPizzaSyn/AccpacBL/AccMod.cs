using System;
using System.Collections.Generic;
using System.Text;

namespace AccpacBL
{
    public class AccMod
    {
        private string _strModName = "";
        private string _strModVersion = "";
        private string _strModFullName = "";
        private bool _blnActivation = false;
        private bool _blnChecked = false;

        public string ModName
        {
            get { return _strModName; }
            set { _strModName = value; }
        }

        public string ModVersion
        {
            get { return _strModVersion; }
            set { _strModVersion = value; }
        }

        public string ModFullName
        {
            get { return _strModFullName; }
            set { _strModFullName = value; }
        }

        public bool Activation
        {
            get { return _blnActivation; }
            set { _blnActivation = value; }
        }

        public bool Checked
        {
            get { return _blnChecked; }
            set { _blnChecked = value; }
        }
    }
}
