using System;
using System.Collections.Generic;
using System.Text;
using AccpacSessionManager;
using AccpacCOMAPI;
//using System.Transactions;

namespace AccpacBL
{
    public enum DatabaseType
    {
        MSSqlServer = 1,
        Pervasive,
        Oracle,
        IBMDB2,
    }

    public class AccpacLogOn
    {
        private AccpacCOMAPI.AccpacDBLink mDBLinkCmpRW;
        private AccpacCOMAPI.AccpacDBLink mDBLinkSysRW;
        private AccpacCOMAPI.AccpacSession mSession;
        private string mstrCurrVersion;
        private string mstrCompanyID;
        private string mstrUserID;
        private string mstrPwd;
        private DateTime mdtSessionDate;

        public AccpacLogOn() { }
        public AccpacLogOn(string currVersion)
        {
            mstrCurrVersion = currVersion;
        }

        public AccpacCOMAPI.AccpacDBLink ACDBLinkCmpRW
        {
            get { return mDBLinkCmpRW; }
            set { mDBLinkCmpRW = value; }
        }

        public AccpacCOMAPI.AccpacDBLink ACDBLinkSysRW
        {
            get { return mDBLinkSysRW; }
            set { mDBLinkSysRW = value; }
        }

        public AccpacCOMAPI.AccpacSession ACSession
        {
            get { return mSession; }
            set { mSession = value; }
        }

        public string CurrVersion
        {
            get { return mstrCurrVersion; }
            set { mstrCurrVersion = value; }
        }

        public string CompanyID
        {
            get { return mstrCompanyID; }
            set { mstrCompanyID = value; }
        }

        public string UserID
        {
            get { return mstrUserID; }
            set { mstrUserID = value; }
        }

        public string Pwd
        {
            get { return mstrPwd; }
            set { mstrPwd = value; }
        }

        public DateTime dtSessionDate
        { 
            get { return mdtSessionDate; }
            set { mdtSessionDate = value; }
        }
        
        #region Open Session
        public bool OpenSessionDBLink(out string sError)
        {
            sError = string.Empty;
            try
            {
                if (mSession == null)
                {
                    mSession = new AccpacCOMAPI.AccpacSession();
                }

                if (mSession.IsOpened == true)
                    mSession.Close();
                mSession.Init("", "AS", "AS0001", mstrCurrVersion);                
                mSession.Open(mstrUserID, mstrPwd, mstrCompanyID, mdtSessionDate, 0, "");                
                mstrCompanyID = mSession.CompanyID;

                mDBLinkCmpRW = mSession.OpenDBLink(tagDBLinkTypeEnum.DBLINK_COMPANY, tagDBLinkFlagsEnum.DBLINK_FLG_READWRITE);
                //mDBLinkSysRW = mSession.OpenDBLink(tagDBLinkTypeEnum.DBLINK_SYSTEM, tagDBLinkFlagsEnum.DBLINK_FLG_READWRITE);

                return true;
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.Message);
                //throw new Exception(ex.Message);
                sError = ex.Message.ToString().Trim();
                return false;
            }
        }
        #endregion

        public void CloseSession()
        {
            try
            {
                if (mDBLinkCmpRW != null)
                    mDBLinkCmpRW.Close();
                if (mDBLinkSysRW != null)
                    mDBLinkSysRW.Close();
                if (mSession != null)
                {
                    if (mSession.IsOpened == true)
                        mSession.Close();
                    mSession = null;
                }
                mDBLinkCmpRW = null;
                mDBLinkSysRW = null;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public DatabaseType GetCompanyDatabaseType()
        {
            DatabaseType dbType = DatabaseType.MSSqlServer;
            switch (mDBLinkCmpRW.DatabaseSeries)
            {
                case tagDatabaseSeries.DB_SQLSERVER:
                    dbType = DatabaseType.MSSqlServer;
                    break;
                case tagDatabaseSeries.DB_PERVASIVE:
                    dbType = DatabaseType.Pervasive;
                    break;
                case tagDatabaseSeries.DB_ORACLE:
                    dbType = DatabaseType.Oracle;
                    break;
                case tagDatabaseSeries.DB_DB2:
                    dbType = DatabaseType.IBMDB2;
                    break;
            }
            return dbType;
        }

        public string DealAccapcError()
        {
            string strError = "";
            for (int intI = 0; intI < ACSession.Errors.Count; intI++)
            {
                if (!strError.Contains(ACSession.Errors.Item(intI)))
                {
                    strError += ACSession.Errors.Item(intI) + "\n";
                }
            }
            ACSession.Errors.Clear();

            return strError;
        }

    }
}
