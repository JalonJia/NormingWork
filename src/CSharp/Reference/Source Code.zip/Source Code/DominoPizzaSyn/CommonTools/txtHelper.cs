﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
using System.IO;
using System.Data.Odbc;
using System.Windows.Forms;
using System.Reflection;
namespace CommonTools
{
    public class txtHelper
    {
        public string _strFileNameWithFullPath = string.Empty;

        //method(s)
        public void writeTXTFile(string strFileNameWithFullPath, string sLogTitle, List<string> lstLog)
        {
            StreamWriter sw = new StreamWriter(strFileNameWithFullPath, false);
            try
            {
                if (!string.IsNullOrEmpty(sLogTitle.Trim()))
                {
                    string strValue = sLogTitle.Trim() + Environment.NewLine + Environment.NewLine;
                }
                foreach (string objT in lstLog)
                {
                    Application.DoEvents();
                    sw.Write(objT.ToString().Trim() + Environment.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                sw = null;
            }
        }

        public void writeTXTFile(string strFileNameWithFullPath, string sLogTitle, string sLog)
        {
            StreamWriter sw = new StreamWriter(strFileNameWithFullPath, false);
            try
            {
                if (!string.IsNullOrEmpty(sLogTitle.Trim()))
                {
                    string strValue = sLogTitle.Trim() + Environment.NewLine + Environment.NewLine;
                }
                sw.Write(sLog.Trim() + Environment.NewLine);
                sw.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                sw = null;
            }
        }
    }
}
