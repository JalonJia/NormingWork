﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;
using System.IO;
using System.Data.Odbc;
using System.Windows.Forms;
using System.Reflection;

namespace CommonTools
{
    public class LogHelper
    {
        public string _strFileNameWithFullPath = string.Empty;

        //method(s)
        public void writeLogFile(string strFileNameWithFullPath, string sLogTitle, List<string> lstLog)
        {
            StreamWriter sw = new StreamWriter(strFileNameWithFullPath, false);
            try
            {
                if (!string.IsNullOrEmpty(sLogTitle.Trim()))
                {
                    string strValue = sLogTitle.Trim() + Environment.NewLine + Environment.NewLine;
                }
                foreach (string objT in lstLog)
                {
                    Application.DoEvents();
                    sw.Write(objT.ToString().Trim() + Environment.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                sw = null;
            }
        }

        public void writeLogFile(string strFullFolderPath, string sFileName, string sLogTitle, List<string> lstLog)
        {
            if (Directory.Exists(strFullFolderPath) == false)
            {
                Directory.CreateDirectory(strFullFolderPath);
            }

            StreamWriter sw = new StreamWriter(strFullFolderPath + sFileName, false);
            try
            {
                if (!string.IsNullOrEmpty(sLogTitle.Trim()))
                {
                    string strValue = sLogTitle.Trim() + Environment.NewLine + Environment.NewLine;
                }
                foreach (string objT in lstLog)
                {
                    Application.DoEvents();
                    sw.Write(objT.ToString().Trim() + Environment.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                sw = null;
            }
        }

        public void writeLogFile(string strFileNameWithFullPath, string sLogTitle, string sLog)
        {
            StreamWriter sw = new StreamWriter(strFileNameWithFullPath, false);
            try
            {
                if (!string.IsNullOrEmpty(sLogTitle.Trim()))
                {
                    string strValue = sLogTitle.Trim() + Environment.NewLine + Environment.NewLine;
                }
                sw.Write(sLog.Trim() + Environment.NewLine);
                sw.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                sw = null;
            }
        }

        public void writeLogFile(string strFullFolderPath, string sFileName, string sLogTitle, string sLog)
        {
            if (Directory.Exists(strFullFolderPath) == false)
            {
                Directory.CreateDirectory(strFullFolderPath);
            }
            StreamWriter sw = new StreamWriter(strFullFolderPath + sFileName, false);
            try
            {
                if (!string.IsNullOrEmpty(sLogTitle.Trim()))
                {
                    string strValue = sLogTitle.Trim() + Environment.NewLine + Environment.NewLine;
                }
                sw.Write(sLog.Trim() + Environment.NewLine);
                sw.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                sw = null;
            }
        }

        public void writeLogFile(string strFullFolderPath, string sFileName, string sLogTitle, string sLog, bool bOverWrite)
        {
            if (Directory.Exists(strFullFolderPath) == false)
            {
                Directory.CreateDirectory(strFullFolderPath);
            }

            if (bOverWrite)
            {
                if (File.Exists(strFullFolderPath + sFileName))
                {
                    File.Delete(strFullFolderPath + sFileName);
                }
            }
            StreamWriter sw = new StreamWriter(strFullFolderPath + sFileName, false);
            try
            {
                if (!string.IsNullOrEmpty(sLogTitle.Trim()))
                {
                    string strValue = sLogTitle.Trim() + Environment.NewLine + Environment.NewLine;
                }
                sw.Write(sLog.Trim() + Environment.NewLine);
                sw.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                sw = null;
            }
        }
    }
}
