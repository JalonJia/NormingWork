using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace CommonTools
{

    public class TripleDESCryptography
    {
        public static string Encrypt(string strValue)
        {
            string sTempValue = string.Empty;
            string sEncode = string.Empty;
            int iAsc;
            char cCharValue;

            for (int i = 0; i < strValue.Length; i++)
            {
                sTempValue = strValue.Substring(i, 1);
                cCharValue = char.Parse(sTempValue);
                iAsc = (int)cCharValue;
                sTempValue = iAsc.ToString("x");
                if (sTempValue.Length == 4)
                {
                    sEncode = sEncode + sTempValue;
                }
                else
                {
                    sEncode = sEncode + "00" + sTempValue;
                }
            }
            sEncode = sEncode.Replace("00", "Z");

            return sEncode;
        }

        public static string Decrypt(string strValue)
        {
            string sTempValue = string.Empty;
            string sDecode = string.Empty;
            int sHexValue;

            strValue = strValue.Replace("Z", "00");
            if (string.IsNullOrEmpty(strValue.Trim()))
            {
            }
            else
            {
                for (int i = 0; i < strValue.Length; i = i + 4)
                {
                    sTempValue = strValue.Substring(i, 4);
                    sHexValue = Convert.ToInt32(sTempValue, 16);// Convert.ToString(sTempValue, 16);
                    sDecode = sDecode + Char.ConvertFromUtf32(sHexValue).ToString();
                }
            }

            return sDecode;
        }

        public static string Encrypt(string strValue, string strKey)
        {

            byte[] keyArray = null;
            byte[] toEncryptArray = null;
            MD5CryptoServiceProvider hashmd5 = default(MD5CryptoServiceProvider);
            TripleDESCryptoServiceProvider tdes = default(TripleDESCryptoServiceProvider);
            ICryptoTransform cTransform = default(ICryptoTransform);
            byte[] resultArray = null;
            toEncryptArray = UTF8Encoding.UTF8.GetBytes(strValue);

            hashmd5 = new MD5CryptoServiceProvider();
            keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(strKey));
            hashmd5.Clear();

            tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            cTransform = tdes.CreateEncryptor();
            resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);

        }

        public static string Decrypt(string strValue, string strKey)
        {
            byte[] keyArray = null;
            byte[] toEncryptArray = null;
            MD5CryptoServiceProvider hashmd5 = default(MD5CryptoServiceProvider);
            TripleDESCryptoServiceProvider tdes = default(TripleDESCryptoServiceProvider);
            ICryptoTransform cTransform = default(ICryptoTransform);
            byte[] resultArray = null;

            toEncryptArray = Convert.FromBase64String(strValue);

            hashmd5 = new MD5CryptoServiceProvider();
            keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(strKey));
            hashmd5.Clear();

            tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            cTransform = tdes.CreateDecryptor();
            resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            tdes.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }

        public static string DES3Encrypt(string sEncrypt, string sKey)
        {
            TripleDESCryptoServiceProvider DES = new TripleDESCryptoServiceProvider();

            DES.Key = ASCIIEncoding.ASCII.GetBytes(sKey);
            DES.Mode = CipherMode.CBC;
            DES.Padding = PaddingMode.PKCS7;

            ICryptoTransform DESEncrypt = DES.CreateEncryptor();

            byte[] Buffer = ASCIIEncoding.ASCII.GetBytes(sEncrypt);
            return Convert.ToBase64String(DESEncrypt.TransformFinalBlock(Buffer, 0, Buffer.Length));
        }

        public static string DES3Decrypt(string sDecrypt, string sKey)
        {
            TripleDESCryptoServiceProvider DES = new TripleDESCryptoServiceProvider();

            DES.Key = ASCIIEncoding.ASCII.GetBytes(sKey);
            DES.Mode = CipherMode.CBC;
            DES.Padding = System.Security.Cryptography.PaddingMode.PKCS7;

            ICryptoTransform DESDecrypt = DES.CreateDecryptor();

            string result = "";
            try
            {
                byte[] Buffer = Convert.FromBase64String(sDecrypt);
                result = ASCIIEncoding.ASCII.GetString(DESDecrypt.TransformFinalBlock(Buffer, 0, Buffer.Length));
            }
            catch (Exception e)
            {

            }
            return result;
        }

        #region DES���ܽ���
        /// <summary>
        /// DES����
        /// </summary>
        /// <param name="sEncrypt">��������</param>
        /// <param name="sKey">8λ�ַ�����Կ�ַ���</param>
        /// <param name="sIv">8λ�ַ��ĳ�ʼ�������ַ���</param>
        /// <returns></returns>
        public static string DESEncrypt(string sEncrypt, string sKey, string sIv)
        {
            byte[] byKey = System.Text.ASCIIEncoding.ASCII.GetBytes(sKey);
            byte[] byIV = System.Text.ASCIIEncoding.ASCII.GetBytes(sIv);

            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            int i = cryptoProvider.KeySize;
            MemoryStream ms = new MemoryStream();
            CryptoStream cst = new CryptoStream(ms, cryptoProvider.CreateEncryptor(byKey, byIV), CryptoStreamMode.Write);

            StreamWriter sw = new StreamWriter(cst);
            sw.Write(sEncrypt);
            sw.Flush();
            cst.FlushFinalBlock();
            sw.Flush();
            return Convert.ToBase64String(ms.GetBuffer(), 0, (int)ms.Length);
        }

        /// <summary>
        /// DES����
        /// </summary>
        /// <param name="data">��������</param>
        /// <param name="sKey">8λ�ַ�����Կ�ַ���(��Ҫ�ͼ���ʱ��ͬ)</param>
        /// <param name="sIv">8λ�ַ��ĳ�ʼ�������ַ���(��Ҫ�ͼ���ʱ��ͬ)</param>
        /// <returns></returns>
        public static string DESDecrypt(string sDecrypt, string sKey, string sIv)
        {
            byte[] byKey = System.Text.ASCIIEncoding.ASCII.GetBytes(sKey);
            byte[] byIV = System.Text.ASCIIEncoding.ASCII.GetBytes(sIv);

            byte[] byEnc;
            try
            {
                byEnc = Convert.FromBase64String(sDecrypt);
            }
            catch
            {
                return null;
            }

            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            MemoryStream ms = new MemoryStream(byEnc);
            CryptoStream cst = new CryptoStream(ms, cryptoProvider.CreateDecryptor(byKey, byIV), CryptoStreamMode.Read);
            StreamReader sr = new StreamReader(cst);
            return sr.ReadToEnd();
        }
        #endregion
    }
}
