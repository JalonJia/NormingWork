using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Data.Common;
using System.Configuration;
using System.IO;
using System.Collections;

namespace CommonTools
{
    public class DbTools
    {
        private DbTools() { }

        private static string _strConnectionstring;

        public static string ConnectionString
        {
            get { return _strConnectionstring; }
            set { _strConnectionstring = value; }
        }

        /// <summary>
        /// save before CheckConnection error message.
        /// </summary>
        private static string _strErrorMessage;

        public static string ErrorMessage
        {
            get { return _strErrorMessage; }
            set { _strErrorMessage = value; }
        }

        private static SqlConnection conn = new SqlConnection();

        public static SqlConnection DatabaseConnection
        {
            get { return DbTools.conn; }
        }
        protected static SqlCommand comm = new SqlCommand();


        /// <summary>
        /// OpenConnection
        /// </summary>
        /// <param name="ConnectionString"></param>
        private static void OpenConnection()
        {
            if (conn.State == ConnectionState.Closed)
            {
                //eg��"server=localhost;database=databasename;uid=sa;pwd=;"
                if (string.IsNullOrEmpty(_strConnectionstring))
                {
                    throw new NullReferenceException("ConnectionString is null or Empty.");
                }
                conn.ConnectionString = _strConnectionstring;
                comm.Connection = conn;
                try
                {
                    conn.Open();
                }
                catch (Exception e)
                {
                    throw new Exception(e.Message);
                }
            }
        }

        /// <summary>
        /// CloseConnection
        /// </summary>
        private static void CloseConnection()
        {
            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Dispose();
            comm.Dispose();
        }

        /// <summary>
        /// Execute Select Sql,return SqlDataReader, when you not use SqlDataReader,you must close() it.
        /// </summary>
        /// <param name="sqlstr">Input Sql</param>
        /// <returns>SqlDataReader</returns>
        public static SqlDataReader GetDataReader(string sqlstr)
        {
            SqlDataReader dr = null;
            try
            {
                OpenConnection();
                comm.CommandText = sqlstr;
                comm.CommandType = CommandType.Text;
                dr = comm.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch
            {
                try
                {
                    dr.Close();
                    CloseConnection();
                }
                catch(Exception e)
                {
                    throw new Exception(e.Message);
                }
            }
            return dr;
        }

        /// <summary>
        /// Execute Select Sql,put data into SqlDataReader , when you not use SqlDataReader,you must close() it.
        /// </summary>
        /// <param name="sqlstr">Input Sql</param>
        /// <param name="dr">ref DataReader dr</param>
        public static void GetDataReader(string sqlstr, ref SqlDataReader dr)
        {
            try
            {
                OpenConnection();
                comm.CommandText = sqlstr;
                comm.CommandType = CommandType.Text;
                dr = comm.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch(Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        /// <summary>
        /// Execute Select Sql,return DataSet
        /// </summary>
        /// <param name="sqlstr">Input Sql</param>
        /// <returns>DataSet</returns>
        public static DataSet GetDataSet(string sqlstr)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter da;
            try
            {
                OpenConnection();
                comm.CommandType = CommandType.Text;
                comm.CommandText = sqlstr;
                da = new SqlDataAdapter();
                da.SelectCommand = comm;
                da.Fill(ds);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                CloseConnection();
            }
            return ds;
        }

        /// <summary>
        /// Execute Select Sql,put data into DataSet 
        /// </summary>
        /// <param name="sqlstr">Input Sql</param>
        /// <param name="ds">ref DataSet ds</param>
        public static void GetDataSet(string sqlstr, ref DataSet ds)
        {
            SqlDataAdapter da;
            try
            {
                OpenConnection();
                comm.CommandType = CommandType.Text;
                comm.CommandText = sqlstr;
                da = new SqlDataAdapter();
                da.SelectCommand = comm;
                da.Fill(ds);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }
        /// <summary>
        /// Execute Select Sql,return DataTable 
        /// </summary>
        /// <param name="sqlstr">Input Sql</param>
        /// <returns>DataTable</returns>
        public static DataTable GetDataTable(string sqlstr)
        {
            SqlDataAdapter da;
            DataTable datatable = new DataTable();
            try
            {
                OpenConnection();
                comm.CommandType = CommandType.Text;
                comm.CommandText = sqlstr;
                da = new SqlDataAdapter();
                da.SelectCommand = comm;
                da.Fill(datatable);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                CloseConnection();
            }
            return datatable;
        }

        /// <summary>
        /// Execute Select Sql,put data into DataTable 
        /// </summary>
        /// <param name="sqlstr">Input SQL</param>
        /// <param name="dt">ref DataTable dt</param>
        public static void GetDataTable(string sqlstr, ref DataTable dt)
        {
            SqlDataAdapter da;
            try
            {
                OpenConnection();
                comm.CommandType = CommandType.Text;
                comm.CommandText = sqlstr;
                da = new SqlDataAdapter();
                da.SelectCommand = comm;
                da.Fill(dt);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        /// <summary>
        /// Execute Sql
        /// </summary>
        /// <param name="sqlstr">Input Sql</param>
        public static void ExecuteSql(string sqlstr)
        {
            try
            {
                OpenConnection();
                comm.CommandType = CommandType.Text;
                comm.CommandText = sqlstr;
                comm.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                CloseConnection();
            }
        }

        /// <summary>
        /// return single value , type is object. if select not one ,it will return the first item.
        /// </summary>
        /// <param name="sqlstr">Input Sql</param>
        /// <returns>object</returns>
        public static object ExecuteScalar(string sqlstr)
        {
            object obj = new object();
            try
            {
                OpenConnection();
                comm.CommandType = CommandType.Text;
                comm.CommandText = sqlstr;
                obj = comm.ExecuteScalar();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                CloseConnection();
            }
            return obj;
        }

        /// <summary>
        /// return single value , type is object. if select not one ,it will return the first item.
        /// </summary>
        /// <param name="sqlstr">Input Sql</param>
        /// <returns>object</returns>
        public static object ExecuteReader(string sqlstr)
        {
            object obj = new object();
            try
            {
                OpenConnection();
                comm.CommandType = CommandType.Text;
                comm.CommandText = sqlstr;
                obj = comm.ExecuteReader();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                CloseConnection();
            }
            return obj;
        }

        /// <summary>
        /// check Connection when some error will return false and save error massage to DbTools.ErrorMessage
        /// </summary>
        /// <returns></returns>
        public static bool CheckConnection()
        {
            try
            {
                OpenConnection();
            }
            catch (Exception e)
            {
                ErrorMessage = e.Message.ToString();
                return false;
            }
            finally
            {
                CloseConnection();
            }
            return true;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileBatch"></param>
        /// <returns>return error file count</returns>
        public static int ExecuteSqlFileBatch(List<string> fileBatch)
        {
            int i = 0;
            foreach (string filePath in fileBatch)
            {
                try
                {
                    ExecuteSqlFile(filePath);
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    i++;
                }
            }
            return i;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="strFileName"></param>
        /// <returns></returns>
        public static void ExecuteSqlFile(string strFileName)
        {
            if (!File.Exists(strFileName))
            {
                throw new FileNotFoundException("Sql File:" + strFileName + " not found.");
            }
            StreamReader rs = new StreamReader(strFileName, System.Text.Encoding.Default);
            List<string> sqlList = new List<string>();
            StringBuilder commandText = new StringBuilder();
            string strLine = "";
            while (rs.Peek() > -1)
            {
                strLine = rs.ReadLine();
                if (strLine.Trim().Equals(""))
                {
                    continue;
                }
                if (!strLine.ToUpper().Equals("GO"))
                {
                    commandText.Append(strLine);
                    commandText.Append("\r\n");
                }
                else
                {
                    if (commandText.Length != 0)
                    {
                        sqlList.Add(commandText.ToString());
                        commandText.Remove(0, commandText.Length);
                    }
                }
            }
            rs.Close();
            try
            {
                ExecuteBatchSql(sqlList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// exec batch sql with transaction
        /// </summary>
        /// <param name="sqlList"></param>
        public static void ExecuteBatchSqlByTransaction(List<string> sqlList)
        {
            OpenConnection();
            SqlTransaction sqlTrans = conn.BeginTransaction();
            comm.Transaction = sqlTrans;

            try
            {
                foreach (string commandText in sqlList)
                {
                    comm.CommandText = commandText;
                    comm.ExecuteNonQuery();
                }
                sqlTrans.Commit();
            }
            catch (Exception ex)
            {
                sqlTrans.Rollback();
                throw ex;
            }
            finally
            {
                CloseConnection();
            }
        }

        /// <summary>
        /// no transaction
        /// </summary>
        /// <param name="sqlList"></param>
        /// <returns>return error sql count</returns>
        public static int ExecuteBatchSql(List<string> sqlList) 
        {
            int i = 0;

            OpenConnection();

                foreach (string commandText in sqlList)
                {
                    try
                    {
                        comm.CommandType = CommandType.Text;
                        comm.CommandText = commandText;
                        comm.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        i++;
                    }
                }

            CloseConnection();
            return i;
        }
    }
}
