﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;

namespace CommonTools
{
    public class publicVar
    {
        public string g_strResult = string.Empty;
        public string g_strError = string.Empty;
        public const string S_PUBLIC_KEY = "A2N6M9C1";
        public const string S_PUBLIC_IV = "V6K1H3D7";

        public const string S_ACCOUNT_KEY = "Y8D4L3X6";
        public const string S_ACCOUNT_IV = "G2J1M5Z7";

        public const string STR_AMOUNT_FORMAT_ON_SCREEN = "####0.00";
        public const string STR_COST_FORMAT_IN_DB = "####0.00";
        public const string STR_DATE_FORMAT_IN_DATABASE = "yyyyMMdd";
        public const string STR_DATE_FORMAT_IN_EXCEL = "yyyy-MM-dd";

        public const string STR_APPLICATION_NAME = "LOGIN SETTING";
        public const string STR_SERVER_CAPTION = "PARAMETER01";
        public const string STR_DATABASE_CAPTION = "PARAMETER02";
        public const string STR_USER_CAPTION = "PARAMETER03";
        public const string STR_PASSWORD_CAPTION = "PARAMETER04";
        public const string STR_ACCPAC_COMPANY_ID_CAPTION = "PARAMETER05";
        public const string STR_ACCPAC_USER_ID_CAPTION = "PARAMETER06";
        public const string STR_ACCPAC_PASSWORD_CAPTION = "PARAMETER07";
        public const string STR_APIKEY_CAPTION = "PARAMETER08";
        public const string STR_RETRY_COUNT_CAPTION = "PARAMETER09";
        public const string STR_RETRIAL_INTERVAL_CAPTION = "PARAMETER10";

        public const string STR_WEB_API_URL_PO_CAPTION = "PARAMETER11";
        public const string STR_WEB_API_URL_OE_CAPTION = "PARAMETER12";
        public const string STR_WEB_API_URL_IC_CAPTION = "PARAMETER13";
        public const string STR_WEB_API_USER_CAPTION = "PARAMETER14";

        public const string STR_SETTING_FILE_NAME = "setting.ini";

        public const string STR_TASK_SCHEDULE_SUFFIX = "-SageSchedule";

        public const string STR_LOGTABLE_POORDER = "LOGPOORD";
        public const string STR_LOGTABLE_OESHIP = "LOGOESHP";
        public const string STR_LOGTABLE_ICINT = "LOGICINT";

        public const string STR_ACCPAC_VERSION = "63A";

        public const int I_MS = 1000;
        public const int I_SECOND = 60;

        public const string S_STATUS_NON_SYN = "0";
        public const string S_STATUS_SUCCEED_SYN = "1";

        public enum ENUM_OE_Order_Status
        {
            NotImport = 0,
            Succeed=1,
            Failed=2
        }
    }
}